# 파일 정리 (FileOrganizer)
Kotlin + Jetpack Compose 안드로이드 파일정리 앱. 저장소 접근 권한(SAF) 방식이라 사용자가 선택한 폴더만 처리합니다.

## APK 받기
1. GitHub에 새 저장소를 만들고 이 폴더 내용을 `main` 브랜치에 push
2. 저장소의 **Actions → Build APK** 실행 완료 대기 (수동 실행: Run workflow)
3. 실행 결과 하단 **Artifacts → FileOrganizer-APK** 다운로드 → 압축 해제 → `app-debug.apk`를 폰에 설치 (출처를 알 수 없는 앱 설치 허용 필요)

## 로컬 빌드
Android Studio에서 이 폴더 열기 → Run. (JDK 17)
