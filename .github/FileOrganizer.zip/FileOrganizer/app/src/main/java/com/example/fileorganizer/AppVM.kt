package com.example.fileorganizer

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.ZoneId

class AppVM(app: Application) : AndroidViewModel(app) {
    private val ctx: Context = app.applicationContext
    private val prefs = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)
    private val store = HistoryStore(ctx)

    var tree by mutableStateOf(prefs.getString("tree", null)?.let { Uri.parse(it) })
        private set
    val excluded = mutableStateListOf<String>().apply {
        addAll(prefs.getStringSet("excluded", emptySet()) ?: emptySet())
    }
    val history = mutableStateListOf<Batch>().apply { addAll(store.load()) }
    var busy by mutableStateOf(false)
        private set
    var done by mutableIntStateOf(0)
        private set
    var total by mutableIntStateOf(0)
        private set
    var status by mutableStateOf("")
        private set
    var result by mutableStateOf<Stats?>(null)
        private set
    var live by mutableStateOf<List<String>>(emptyList())
        private set
    var currentFile by mutableStateOf("")
        private set

    private fun pushLive(s: String) {
        live = (live + s).takeLast(8)
    }

    val plan = mutableStateListOf<PlanItem>()
    var planTitle by mutableStateOf("")
    val groups = mutableStateListOf<DupGroup>()
    val selected = mutableStateListOf<String>()

    @Volatile
    private var cancelFlag = false

    // ---------- 설정 ----------
    fun selectTree(uri: Uri) {
        try {
            ctx.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (e: Exception) {
        }
        prefs.edit().putString("tree", uri.toString()).apply()
        tree = uri
        clearPlan()
    }

    fun folderLabel(): String = tree?.let { Uri.decode(DocumentsContract.getTreeDocumentId(it)) } ?: "선택된 폴더 없음"

    fun addExcluded(name: String) {
        val n = name.trim()
        if (n.isNotEmpty() && n !in excluded) {
            excluded.add(n)
            prefs.edit().putStringSet("excluded", excluded.toSet()).apply()
        }
    }

    fun removeExcluded(name: String) {
        excluded.remove(name)
        prefs.edit().putStringSet("excluded", excluded.toSet()).apply()
    }

    private fun exSet() = excluded.map { it.lowercase() }.toSet()
    private fun docs(): Docs? {
        val t = tree
        if (t == null) status = "먼저 정리할 폴더를 선택하세요"
        return t?.let { Docs(ctx, it) }
    }

    fun clearPlan() {
        plan.clear(); groups.clear(); selected.clear(); dropCache()
        result = null
        if (!busy) status = ""
    }

    fun cancel() {
        cancelFlag = true
    }

    private fun launchWork(block: suspend () -> Unit) {
        if (busy) return
        busy = true; cancelFlag = false; done = 0; total = 0; result = null; live = emptyList(); currentFile = ""
        viewModelScope.launch {
            try {
                block()
            } catch (e: Exception) {
                status = "오류: ${e.message}"
            } finally {
                busy = false; currentFile = ""
            }
        }
    }

    private suspend fun scanFiles(d: Docs, recursive: Boolean): List<Entry> {
        status = "파일 검색 중…"
        return withContext(Dispatchers.IO) {
            d.scan(recursive, exSet(), { cancelFlag }) { n ->
                if (n % 20 == 0) status = "파일 검색 중… ${n}개"
            }
        }
    }

    // ---------- 종류별 / 날짜별 ----------
    fun planMove(byType: Boolean, recursive: Boolean) = launchWork {
        val d = docs() ?: return@launchWork
        plan.clear()
        val files = scanFiles(d, recursive)
        if (cancelFlag) {
            status = "취소됨"; return@launchWork
        }
        val zone = ZoneId.systemDefault()
        val items = files.map { e ->
            val dest = if (byType) Category.of(e.name).label
            else if (e.modified > 0) {
                val dt = Instant.ofEpochMilli(e.modified).atZone(zone)
                "%04d/%02d".format(dt.year, dt.monthValue)
            } else "날짜없음"
            val skip = if (e.relDir == dest || e.relDir.startsWith("$dest/")) "이미 해당 폴더에 있음" else null
            PlanItem(e, "move", dest, skipReason = skip)
        }
        plan.addAll(items)
        planTitle = if (byType) "종류별 정리" else "날짜별 정리"
        status = "미리보기: 파일 ${items.size}개"
    }

    // ---------- 일괄 이름 변경 ----------
    private var cached: List<Entry> = emptyList()
    var cachedCount by mutableIntStateOf(0)
        private set

    fun loadFiles(recursive: Boolean) = launchWork {
        val d = docs() ?: return@launchWork
        plan.clear(); cached = emptyList(); cachedCount = 0
        val files = scanFiles(d, recursive)
        if (cancelFlag) {
            status = "취소됨"; return@launchWork
        }
        cached = files; cachedCount = files.size
        status = "파일 ${files.size}개를 불러왔습니다"
    }

    fun dropCache() {
        cached = emptyList(); cachedCount = 0
    }

    /** 입력이 바뀔 때마다 호출: 불러온 파일 목록으로 변경 전/후를 즉시 계산 */
    fun rebuildRename(words: String, caseSensitive: Boolean, partial: Boolean, brackets: String) {
        plan.clear()
        val ws = words.split(',', '\n').map { it.trim() }.filter { it.isNotEmpty() }
            .distinct().sortedByDescending { it.length }
        if (ws.isEmpty() && brackets.isEmpty()) {
            status = "제거할 단어를 입력하거나 괄호를 선택하세요"; return
        }
        val opts = if (caseSensitive) emptySet() else setOf(RegexOption.IGNORE_CASE)
        val regs = ws.map { w ->
            val q = Regex.escape(w)
            Regex(if (partial) q else "(?<![\\p{L}\\p{N}])$q(?![\\p{L}\\p{N}])", opts)
        }
        // 괄호 한 쌍 + 안의 내용 (안쪽부터 반복 삭제해 중첩도 처리)
        val brRegs = brackets.map { o ->
            val c = when (o) { '(' -> ')'; '[' -> ']'; '{' -> '}'; else -> '>' }
            Regex("\\" + o + "[^\\" + o + "\\" + c + "]*\\" + c)
        }
        val names = HashMap<String, MutableSet<String>>()
        cached.forEach { names.getOrPut(it.parentDocId) { HashSet() }.add(it.name) }
        val spaces = Regex("\\s+")
        val items = ArrayList<PlanItem>()
        for (e in cached) {
            val (base, ext) = splitExt(e.name)
            var b = base
            for (r in brRegs) {
                var prev = ""
                while (b != prev) {
                    prev = b; b = r.replace(b, "")
                }
            }
            for (r in regs) b = r.replace(b, "")
            if (b == base) continue
            b = b.replace(spaces, " ").trim()
            if (b.isEmpty()) {
                items.add(PlanItem(e, "rename", newName = "", skipReason = "변경 후 이름이 비어 있음")); continue
            }
            val nn = b + ext
            if (nn == e.name) continue
            if (!nn.endsWith(ext)) continue // 확장자는 절대 변경하지 않음
            val set = names.getOrPut(e.parentDocId) { HashSet() }
            if (nn in set) {
                items.add(PlanItem(e, "rename", newName = nn, skipReason = "같은 이름의 파일이 있음"))
            } else {
                set.remove(e.name); set.add(nn)
                items.add(PlanItem(e, "rename", newName = nn))
            }
        }
        plan.addAll(items)
        planTitle = "일괄 이름 변경"
        status = "변경 대상 ${items.size}개 (전체 ${cached.size}개 중)"
    }

    // ---------- 적용 ----------
    fun applyPlan() = launchWork {
        val d = docs() ?: return@launchWork
        val items = plan.filter { it.skipReason == null }
        val pre = plan.size - items.size
        val title = planTitle
        status = "적용 중…"; total = items.size
        val (stats, ops) = withContext(Dispatchers.IO) { execute(d, items, pre) }
        finish(title, d, stats, ops)
        plan.clear()
        if (title == "일괄 이름 변경") dropCache()
    }

    private fun finish(title: String, d: Docs, stats: Stats, ops: List<Op>) {
        result = stats
        status = if (stats.cancelled) "취소됨 (이미 처리된 파일은 기록에 남아 있습니다)" else "완료"
        if (ops.isNotEmpty()) {
            history.add(0, Batch(System.currentTimeMillis(), title, d.tree.toString(), ops, stats.ok, stats.fail, stats.skip))
            store.save(history.toList())
        }
    }

    private fun execute(d: Docs, items: List<PlanItem>, pre: Int): Pair<Stats, List<Op>> {
        var ok = 0; var fail = 0; var skip = pre
        val ops = ArrayList<Op>()
        val names = HashMap<String, MutableSet<String>>()
        var i = 0
        while (i < items.size) {
            if (cancelFlag) break
            val p = items[i]; val e = p.e
            currentFile = e.path
            val o0 = ok; val f0 = fail
            try {
                when (p.kind) {
                    "move" -> {
                        val dst = d.ensurePath(p.destRel)
                        val set = names.getOrPut(dst) { d.children(dst).map { c -> c.name }.toMutableSet() }
                        if (e.name in set) skip++
                        else {
                            val nu = d.move(e.uri, e.parentDocId, dst)
                            if (nu == null) fail++
                            else {
                                ok++; set.add(e.name)
                                ops.add(Op("move", e.name, e.name, e.parentDocId, dst, DocumentsContract.getDocumentId(nu), e.path, join(p.destRel, e.name)))
                            }
                        }
                    }
                    "rename" -> {
                        val set = names.getOrPut(e.parentDocId) { d.children(e.parentDocId).map { c -> c.name }.toMutableSet() }
                        if (p.newName.isEmpty() || p.newName in set) skip++
                        else {
                            val nu = d.rename(e.uri, p.newName)
                            if (nu == null) fail++
                            else {
                                ok++; set.remove(e.name); set.add(p.newName)
                                ops.add(Op("rename", e.name, p.newName, e.parentDocId, e.parentDocId, DocumentsContract.getDocumentId(nu), e.path, join(e.relDir, p.newName)))
                            }
                        }
                    }
                    "delete" -> {
                        if (d.delete(e.uri)) {
                            ok++
                            ops.add(Op("delete", e.name, "", e.parentDocId, "", "", e.path, ""))
                        } else fail++
                    }
                }
            } catch (ex: Exception) {
                fail++
            }
            val mark = if (ok > o0) "✓" else if (fail > f0) "✗" else "↷"
            pushLive("$mark ${e.path} → ${if (p.kind == "delete") "(삭제됨)" else planAfter(p)}")
            i++; done = i
        }
        skip += items.size - i
        return Pair(Stats(ok, fail, skip, cancelFlag), ops)
    }

    // ---------- 복구 ----------
    fun undo(b: Batch) = launchWork {
        val d = Docs(ctx, Uri.parse(b.tree))
        val ops = b.ops.filter { it.kind != "delete" }.reversed()
        status = "복구 중…"; total = ops.size
        val stats = withContext(Dispatchers.IO) {
            var ok = 0; var fail = 0; var skip = b.ops.size - ops.size
            val names = HashMap<String, MutableSet<String>>()
            var i = 0
            for (op in ops) {
                if (cancelFlag) break
                currentFile = op.toPath
                val o0 = ok; val f0 = fail
                try {
                    val set = names.getOrPut(op.fromParent) { d.children(op.fromParent).map { c -> c.name }.toMutableSet() }
                    if (op.name in set) skip++
                    else {
                        val nu = if (op.kind == "move") d.move(d.docUri(op.afterId), op.toParent, op.fromParent)
                        else d.rename(d.docUri(op.afterId), op.name)
                        if (nu == null) fail++ else { ok++; set.add(op.name) }
                    }
                } catch (ex: Exception) {
                    fail++
                }
                val mark = if (ok > o0) "↶" else if (fail > f0) "✗" else "↷"
                pushLive("$mark ${op.toPath} → ${op.fromPath}")
                i++; done = i
            }
            skip += ops.size - i
            Stats(ok, fail, skip, cancelFlag)
        }
        dropCache()
        result = stats
        status = "복구 완료 (삭제된 파일은 복구할 수 없습니다)"
        if (!stats.cancelled && stats.fail == 0) {
            val idx = history.indexOfFirst { it.id == b.id }
            if (idx >= 0) history[idx] = history[idx].copy(undone = true)
            store.save(history.toList())
        }
    }

    // ---------- 중복 파일 ----------
    fun findDups(recursive: Boolean, sameName: Boolean) = launchWork {
        val d = docs() ?: return@launchWork
        groups.clear(); selected.clear()
        val files = scanFiles(d, recursive).filter { it.size > 0 }
        val cand = files.groupBy { if (sameName) "${it.size}|${it.name}" else "${it.size}" }
            .values.filter { it.size > 1 }
        total = cand.sumOf { it.size }
        status = "SHA-256 비교 중…"
        val found = withContext(Dispatchers.IO) {
            val out = ArrayList<DupGroup>()
            for (g in cand) {
                if (cancelFlag) break
                val byHash = HashMap<String, MutableList<Entry>>()
                for (e in g) {
                    if (cancelFlag) break
                    currentFile = e.path
                    val h = try { d.sha256(e.uri) } catch (ex: Exception) { null }
                    pushLive("• ${e.path}")
                    done++
                    if (h != null) byHash.getOrPut(h) { ArrayList() }.add(e)
                }
                byHash.values.filter { it.size > 1 }.forEach { out.add(DupGroup(it[0].size, it)) }
            }
            out
        }
        groups.addAll(found)
        status = if (cancelFlag) "취소됨 · 중복 그룹 ${found.size}개" else "중복 그룹 ${found.size}개"
    }

    fun toggle(key: String) {
        if (key in selected) selected.remove(key) else selected.add(key)
    }

    fun autoSelect() {
        selected.clear()
        groups.forEach { g -> g.files.drop(1).forEach { selected.add(it.uri.toString()) } }
    }

    fun deleteSelected() = launchWork {
        val d = docs() ?: return@launchWork
        val items = ArrayList<PlanItem>()
        var pre = 0
        for (g in groups) {
            val sel = g.files.filter { it.uri.toString() in selected }
            // 한 그룹의 파일을 전부 선택해도 1개는 반드시 보존
            val del = if (sel.size == g.files.size) { pre += 1; sel.drop(1) } else sel
            del.forEach { items.add(PlanItem(it, "delete")) }
        }
        status = "삭제 중…"; total = items.size
        val (stats, ops) = withContext(Dispatchers.IO) { execute(d, items, pre) }
        finish("중복 파일 삭제", d, stats, ops)
        val removed = ops.map { it.fromPath }.toSet()
        val ng = groups.map { g -> DupGroup(g.size, g.files.filter { f -> f.path !in removed }) }.filter { it.files.size > 1 }
        groups.clear(); groups.addAll(ng); selected.clear()
    }
}
