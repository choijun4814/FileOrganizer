package com.example.fileorganizer

import android.net.Uri
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun join(a: String, b: String) = if (a.isEmpty()) b else "$a/$b"

data class Entry(
    val uri: Uri, val docId: String, val parentDocId: String,
    val name: String, val size: Long, val modified: Long, val relDir: String
) {
    val path: String get() = join(relDir, name)
}

/** kind: move / rename / delete */
data class PlanItem(
    val e: Entry, val kind: String, val destRel: String = "",
    val newName: String = "", val skipReason: String? = null
)

data class Stats(val ok: Int, val fail: Int, val skip: Int, val cancelled: Boolean = false)

data class Op(
    val kind: String, val name: String, val newName: String,
    val fromParent: String, val toParent: String, val afterId: String,
    val fromPath: String, val toPath: String
)

data class Batch(
    val id: Long, val title: String, val tree: String, val ops: List<Op>,
    val ok: Int, val fail: Int, val skip: Int, val undone: Boolean = false
)

data class DupGroup(val size: Long, val files: List<Entry>)

enum class Category(val label: String, val exts: Set<String>) {
    PHOTO("사진", setOf("jpg", "jpeg", "png", "gif", "bmp", "webp", "heic", "heif", "tif", "tiff", "dng", "raw")),
    VIDEO("동영상", setOf("mp4", "mkv", "avi", "mov", "wmv", "flv", "webm", "3gp", "m4v", "mpg", "mpeg", "ts")),
    DOC("문서", setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "hwp", "hwpx", "txt", "csv", "rtf", "odt", "md")),
    MUSIC("음악", setOf("mp3", "wav", "flac", "aac", "m4a", "ogg", "wma", "opus", "amr", "lrc")),
    ARCHIVE("압축파일", setOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz", "alz", "egg")),
    OTHER("기타", emptySet());

    companion object {
        fun of(name: String): Category {
            val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
            return values().firstOrNull { ext in it.exts } ?: OTHER
        }
    }
}

fun fmtSize(b: Long): String = when {
    b >= 1_073_741_824L -> "%.1f GB".format(b / 1_073_741_824.0)
    b >= 1_048_576L -> "%.1f MB".format(b / 1_048_576.0)
    b >= 1024L -> "%.1f KB".format(b / 1024.0)
    else -> "$b B"
}

fun fmtTime(ms: Long): String = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.KOREA).format(Date(ms))

/** 마지막 확장자 구분자를 기준으로 분리한다. 확장자 길이·문자 종류를 제한하지 않아 원본을 보존한다. */
fun splitExt(name: String): Pair<String, String> {
    val dot = name.lastIndexOf('.')
    // 숨김 파일(.nomedia)이나 점이 없는 파일은 확장자가 없는 것으로 취급
    if (dot <= 0 || dot == name.lastIndex) return Pair(name, "")
    return Pair(name.substring(0, dot), name.substring(dot))
}
