package com.example.fileorganizer

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import java.security.MessageDigest

/** SAF(Storage Access Framework) 헬퍼: 사용자가 허용한 폴더 트리 안에서만 동작 */
class Docs(ctx: Context, val tree: Uri) {
    private val cr = ctx.contentResolver
    val rootId: String = DocumentsContract.getTreeDocumentId(tree)
    private val dirCache = HashMap<String, String>()

    class Child(val id: String, val name: String, val size: Long, val modified: Long, val isDir: Boolean)

    fun docUri(id: String): Uri = DocumentsContract.buildDocumentUriUsingTree(tree, id)

    fun children(parentId: String): List<Child> {
        val uri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
        val cols = arrayOf(
            Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME, Document.COLUMN_SIZE,
            Document.COLUMN_LAST_MODIFIED, Document.COLUMN_MIME_TYPE
        )
        val out = ArrayList<Child>()
        cr.query(uri, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                out.add(
                    Child(
                        c.getString(0), c.getString(1) ?: "",
                        if (c.isNull(2)) 0L else c.getLong(2),
                        if (c.isNull(3)) 0L else c.getLong(3),
                        c.getString(4) == Document.MIME_TYPE_DIR
                    )
                )
            }
        }
        return out
    }

    fun scan(
        recursive: Boolean, excluded: Set<String>,
        cancelled: () -> Boolean, onCount: (Int) -> Unit
    ): List<Entry> {
        val res = ArrayList<Entry>()
        fun walk(id: String, rel: String) {
            if (cancelled()) return
            for (ch in children(id)) {
                if (cancelled()) return
                if (ch.isDir) {
                    if (recursive && ch.name.lowercase() !in excluded) walk(ch.id, join(rel, ch.name))
                } else {
                    res.add(Entry(docUri(ch.id), ch.id, id, ch.name, ch.size, ch.modified, rel))
                    onCount(res.size)
                }
            }
        }
        walk(rootId, "")
        return res
    }

    private fun ensureDir(parent: String, name: String): String {
        val key = "$parent|$name"
        dirCache[key]?.let { return it }
        val found = children(parent).firstOrNull { it.isDir && it.name == name }
        val id = found?.id ?: DocumentsContract.getDocumentId(
            DocumentsContract.createDocument(cr, docUri(parent), Document.MIME_TYPE_DIR, name)
                ?: throw IllegalStateException("폴더 생성 실패: $name")
        )
        dirCache[key] = id
        return id
    }

    fun ensurePath(rel: String): String {
        var cur = rootId
        for (part in rel.split('/')) if (part.isNotEmpty()) cur = ensureDir(cur, part)
        return cur
    }

    fun move(src: Uri, fromParent: String, toParent: String): Uri? =
        DocumentsContract.moveDocument(cr, src, docUri(fromParent), docUri(toParent))

    fun rename(src: Uri, newName: String): Uri? = DocumentsContract.renameDocument(cr, src, newName)

    fun delete(src: Uri): Boolean = DocumentsContract.deleteDocument(cr, src)

    fun sha256(uri: Uri): String? {
        val md = MessageDigest.getInstance("SHA-256")
        val ins = cr.openInputStream(uri) ?: return null
        ins.use { s ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = s.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
