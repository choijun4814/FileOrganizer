package com.example.fileorganizer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/** 작업 전 파일명·경로를 JSON으로 저장 (최근 50건) */
class HistoryStore(ctx: Context) {
    private val file = File(ctx.filesDir, "history.json")

    fun load(): List<Batch> = try {
        val arr = JSONArray(file.readText())
        (0 until arr.length()).map { parse(arr.getJSONObject(it)) }
    } catch (e: Exception) {
        emptyList()
    }

    fun save(list: List<Batch>) {
        try {
            val arr = JSONArray()
            list.take(50).forEach { arr.put(toJson(it)) }
            val tmp = File(file.path + ".tmp")
            tmp.writeText(arr.toString())
            try {
                Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
            } catch (_: Exception) {
                Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING)
            }
        } catch (e: Exception) {
        }
    }

    private fun toJson(b: Batch): JSONObject {
        val ops = JSONArray()
        b.ops.forEach { o ->
            ops.put(
                JSONObject().put("k", o.kind).put("n", o.name).put("nn", o.newName)
                    .put("fp", o.fromParent).put("tp", o.toParent).put("a", o.afterId)
                    .put("f", o.fromPath).put("t", o.toPath)
            )
        }
        return JSONObject().put("id", b.id).put("title", b.title).put("tree", b.tree)
            .put("ok", b.ok).put("fail", b.fail).put("skip", b.skip).put("undone", b.undone)
            .put("ops", ops)
    }

    private fun parse(j: JSONObject): Batch {
        val a = j.getJSONArray("ops")
        val ops = (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Op(
                o.getString("k"), o.getString("n"), o.getString("nn"), o.getString("fp"),
                o.getString("tp"), o.getString("a"), o.getString("f"), o.getString("t")
            )
        }
        return Batch(
            j.getLong("id"), j.getString("title"), j.getString("tree"), ops,
            j.getInt("ok"), j.getInt("fail"), j.getInt("skip"), j.getBoolean("undone")
        )
    }
}
