@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.fileorganizer

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

enum class Screen(val title: String, val desc: String) {
    Main("파일 정리", ""),
    ByType("종류별 정리", "사진·동영상·문서·음악·압축파일·기타로 자동 분류"),
    ByDate("날짜별 정리", "연도/월 폴더로 정리"),
    Dup("중복 파일 찾기", "SHA-256으로 실제 중복 확인 후 선택 삭제"),
    Rename("일괄 이름 변경", "입력한 단어만 파일명에서 제거"),
    History("작업 기록 및 복구", "이전 작업 되돌리기"),
    Settings("설정 및 제외 폴더", "대상 폴더 · 제외 폴더 관리")
}

private val PAD = PaddingValues(12.dp)
private val GAP = Arrangement.spacedBy(10.dp)

@Composable
fun App(vm: AppVM = viewModel()) {
    var screen by rememberSaveable { mutableStateOf(Screen.Main) }
    val go: (Screen) -> Unit = { s -> vm.clearPlan(); screen = s }
    BackHandler(screen != Screen.Main) { go(Screen.Main) }
    Scaffold(topBar = {
        TopAppBar(
            title = { Text(screen.title) },
            navigationIcon = { if (screen != Screen.Main) TextButton(onClick = { go(Screen.Main) }) { Text("←") } }
        )
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (vm.busy) ProgressCard(vm)
            else if (vm.status.isNotEmpty()) Text(vm.status, Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
            when (screen) {
                Screen.Main -> MainScreen(vm, go)
                Screen.ByType -> MoveScreen(vm, true)
                Screen.ByDate -> MoveScreen(vm, false)
                Screen.Dup -> DupScreen(vm)
                Screen.Rename -> RenameScreen(vm)
                Screen.History -> HistoryScreen(vm)
                Screen.Settings -> SettingsScreen(vm)
            }
        }
    }
}

@Composable
fun ProgressCard(vm: AppVM) {
    Card(Modifier.fillMaxWidth().padding(12.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(vm.status)
            if (vm.total > 0) {
                LinearProgressIndicator(progress = { vm.done.toFloat() / vm.total }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
                Text("${vm.done} / ${vm.total}")
            } else {
                LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 8.dp))
            }
            OutlinedButton(onClick = { vm.cancel() }) { Text("작업 취소") }
        }
    }
}

@Composable
fun FolderCard(vm: AppVM) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u -> if (u != null) vm.selectTree(u) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("정리 대상 폴더", style = MaterialTheme.typography.titleMedium)
            Text(vm.folderLabel())
            Button(onClick = { picker.launch(null) }, enabled = !vm.busy) { Text(if (vm.tree == null) "폴더 선택" else "폴더 변경") }
        }
    }
}

@Composable
fun MainScreen(vm: AppVM, go: (Screen) -> Unit) {
    val menus = listOf(Screen.ByType, Screen.ByDate, Screen.Dup, Screen.Rename, Screen.History, Screen.Settings)
    LazyColumn(contentPadding = PAD, verticalArrangement = GAP) {
        item { FolderCard(vm) }
        items(menus) { s ->
            Card(onClick = { go(s) }, enabled = vm.tree != null || s == Screen.History || s == Screen.Settings, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text(s.title, style = MaterialTheme.typography.titleMedium)
                    Text(s.desc, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun SwitchRow(label: String, v: Boolean, on: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, Modifier.weight(1f)); Switch(checked = v, onCheckedChange = on)
    }
}

@Composable
fun ConfirmDialog(msg: String, onOk: () -> Unit, onNo: () -> Unit) {
    AlertDialog(
        onDismissRequest = onNo, title = { Text("확인") }, text = { Text(msg) },
        confirmButton = { TextButton(onClick = onOk) { Text("실행") } },
        dismissButton = { TextButton(onClick = onNo) { Text("취소") } }
    )
}

@Composable
fun LiveCard(vm: AppVM) {
    if (!vm.busy && vm.live.isEmpty()) return
    Card(Modifier.fillMaxWidth()) {
        SelectionContainer {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(if (vm.busy) "처리 중 (실시간)" else "처리 내역 (최근)", style = MaterialTheme.typography.titleSmall)
                if (vm.busy && vm.currentFile.isNotEmpty()) Text("▶ ${vm.currentFile}", style = MaterialTheme.typography.bodySmall)
                vm.live.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
            }
        }
    }
}

@Composable
fun StatsCard(s: Stats) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text("작업 결과" + if (s.cancelled) " (취소됨)" else "", style = MaterialTheme.typography.titleSmall)
            Text("성공 ${s.ok}개 · 실패 ${s.fail}개 · 건너뜀 ${s.skip}개")
        }
    }
}

fun planAfter(p: PlanItem): String =
    if (p.kind == "move") join(p.destRel, p.e.name)
    else if (p.newName.isEmpty()) "-" else join(p.e.relDir, p.newName)

fun planText(p: PlanItem): String =
    "전: ${p.e.path}\n후: ${planAfter(p)}" + (p.skipReason?.let { "\n건너뜀 · $it" } ?: "")

@Composable
fun PlanRow(p: PlanItem) {
    Card(Modifier.fillMaxWidth()) {
        SelectionContainer {
            Column(Modifier.padding(10.dp)) {
                Text("전: ${p.e.path}", style = MaterialTheme.typography.bodySmall)
                Text("후: ${planAfter(p)}", style = MaterialTheme.typography.bodySmall)
                p.skipReason?.let { Text("건너뜀 · $it", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error) }
            }
        }
    }
}

fun LazyListScope.planList(vm: AppVM, onApply: () -> Unit) {
    item { LiveCard(vm) }
    vm.result?.let { r -> item { StatsCard(r) } }
    if (vm.plan.isNotEmpty()) {
        item {
            val ok = vm.plan.count { it.skipReason == null }
            val clip = LocalClipboardManager.current
            var copied by remember { mutableStateOf(false) }
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("적용 대상 ${ok}개 · 건너뜀 ${vm.plan.size - ok}개")
                Button(onClick = onApply, enabled = ok > 0 && !vm.busy) { Text("확인 후 적용") }
                OutlinedButton(onClick = {
                    clip.setText(AnnotatedString(vm.plan.joinToString("\n\n") { planText(it) }))
                    copied = true
                }) { Text(if (copied) "복사됨 ✓ (목록 전체 복사)" else "목록 전체 복사") }
                Text("아래 항목을 길게 누르면 글자를 선택해 복사할 수 있습니다.", style = MaterialTheme.typography.bodySmall)
            }
        }
        items(vm.plan.size) { i -> PlanRow(vm.plan[i]) }
    }
}

@Composable
fun MoveScreen(vm: AppVM, byType: Boolean) {
    var rec by rememberSaveable { mutableStateOf(true) }
    var confirm by remember { mutableStateOf(false) }
    LazyColumn(contentPadding = PAD, verticalArrangement = GAP) {
        item {
            Text(
                if (byType) "확장자 기준으로 정리 폴더 안에 사진/동영상/문서/음악/압축파일/기타 폴더를 만들어 이동합니다."
                else "파일 수정일 기준으로 연도/월 폴더를 만들어 이동합니다. 날짜가 없으면 '날짜없음' 폴더로 이동합니다."
            )
        }
        item { SwitchRow("하위 폴더 포함", rec) { rec = it } }
        item { Button(onClick = { vm.planMove(byType, rec) }, enabled = !vm.busy) { Text("미리보기 만들기") } }
        planList(vm) { confirm = true }
    }
    if (confirm) ConfirmDialog("${vm.plan.count { it.skipReason == null }}개 파일을 이동합니다. 같은 이름의 파일이 있으면 건너뜁니다.", { confirm = false; vm.applyPlan() }, { confirm = false })
}

@Composable
fun RenameScreen(vm: AppVM) {
    var words by rememberSaveable { mutableStateOf("") }
    var rec by rememberSaveable { mutableStateOf(true) }
    var cs by rememberSaveable { mutableStateOf(false) }
    var part by rememberSaveable { mutableStateOf(true) }
    var brk by rememberSaveable { mutableStateOf("") }
    var confirm by remember { mutableStateOf(false) }
    var confirmUndo by remember { mutableStateOf(false) }
    val last = vm.history.firstOrNull { !it.undone && it.ops.any { o -> o.kind != "delete" } }
    // 입력·옵션이 바뀔 때마다 변경 전/후를 즉시 다시 계산
    LaunchedEffect(words, cs, part, brk, vm.cachedCount, vm.busy) {
        if (vm.cachedCount > 0 && !vm.busy) vm.rebuildRename(words, cs, part, brk)
    }
    val pairs = listOf('(' to "( ) 소괄호", '[' to "[ ] 대괄호", '{' to "{ } 중괄호", '<' to "< > 꺾쇠괄호")
    LazyColumn(contentPadding = PAD, verticalArrangement = GAP) {
        item { SwitchRow("하위 폴더 포함", rec) { rec = it } }
        item {
            Button(onClick = { vm.loadFiles(rec) }, enabled = !vm.busy) {
                Text(if (vm.cachedCount == 0) "1. 파일 목록 불러오기" else "파일 목록 다시 불러오기 (${vm.cachedCount}개)")
            }
        }
        item { Text("파일 목록을 불러온 뒤 입력하면 변경 전/후가 바로 아래에 표시됩니다.", style = MaterialTheme.typography.bodySmall) }
        item {
            OutlinedTextField(
                value = words, onValueChange = { words = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text("제거할 단어 (쉼표 또는 줄바꿈으로 구분)") }
            )
        }
        item { Text("괄호와 안의 내용까지 삭제", style = MaterialTheme.typography.titleSmall) }
        pairs.forEach { (ch, label) ->
            item {
                SwitchRow(label, ch in brk) { on -> brk = if (on) brk + ch else brk.replace(ch.toString(), "") }
            }
        }
        item { SwitchRow("대소문자 구분", cs) { cs = it } }
        item { SwitchRow("단어 일부 일치 시에도 제거", part) { part = it } }
        if (last != null) item {
            OutlinedButton(onClick = { confirmUndo = true }, enabled = !vm.busy) { Text("직전 작업 되돌리기: ${last.title}") }
        }
        planList(vm) { confirm = true }
    }
    if (confirm) ConfirmDialog("${vm.plan.count { it.skipReason == null }}개 파일의 이름을 변경합니다. (확장자·내용은 변경되지 않습니다)", { confirm = false; vm.applyPlan() }, { confirm = false })
    if (confirmUndo && last != null) ConfirmDialog("'${last.title}' 작업을 되돌립니다.", { confirmUndo = false; vm.undo(last) }, { confirmUndo = false })
}

@Composable
fun DupScreen(vm: AppVM) {
    var rec by rememberSaveable { mutableStateOf(true) }
    var sameName by rememberSaveable { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    LazyColumn(contentPadding = PAD, verticalArrangement = GAP) {
        item { Text("용량이 같은 파일을 SHA-256 해시로 비교해 실제로 같은 파일만 보여줍니다.") }
        item { SwitchRow("하위 폴더 포함", rec) { rec = it } }
        item { SwitchRow("파일명도 같은 것만 검색", sameName) { sameName = it } }
        item { Button(onClick = { vm.findDups(rec, sameName) }, enabled = !vm.busy) { Text("중복 검색") } }
        item { LiveCard(vm) }
        vm.result?.let { r -> item { StatsCard(r) } }
        if (vm.groups.isNotEmpty()) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.autoSelect() }) { Text("각 그룹 첫 파일만 남기고 선택") }
                    Button(onClick = { confirm = true }, enabled = vm.selected.isNotEmpty() && !vm.busy) { Text("선택 삭제 (${vm.selected.size})") }
                }
            }
        }
        items(vm.groups) { g ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp)) {
                    Text("동일 파일 ${g.files.size}개 · ${fmtSize(g.size)}", style = MaterialTheme.typography.titleSmall)
                    g.files.forEach { e ->
                        val k = e.uri.toString()
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = k in vm.selected, onCheckedChange = { vm.toggle(k) })
                            Column {
                                Text(e.name, style = MaterialTheme.typography.bodyMedium)
                                Text("/" + e.relDir + " · " + fmtTime(e.modified), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
    if (confirm) ConfirmDialog("선택한 ${vm.selected.size}개 파일을 삭제합니다. 삭제는 되돌릴 수 없습니다. (그룹마다 1개는 반드시 보존됩니다)", { confirm = false; vm.deleteSelected() }, { confirm = false })
}

@Composable
fun HistoryScreen(vm: AppVM) {
    var confirmBatch by remember { mutableStateOf<Batch?>(null) }
    LazyColumn(contentPadding = PAD, verticalArrangement = GAP) {
        item { LiveCard(vm) }
        vm.result?.let { r -> item { StatsCard(r) } }
        if (vm.history.isEmpty()) item { Text("작업 기록이 없습니다.") }
        items(vm.history, key = { it.id }) { b ->
            var open by remember { mutableStateOf(false) }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(b.title + if (b.undone) " (복구됨)" else "", style = MaterialTheme.typography.titleSmall)
                    Text("${fmtTime(b.id)} · 성공 ${b.ok} 실패 ${b.fail} 건너뜀 ${b.skip}", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { open = !open }) { Text(if (open) "접기" else "상세") }
                        if (!b.undone && b.ops.any { it.kind != "delete" }) {
                            TextButton(onClick = { confirmBatch = b }, enabled = !vm.busy) { Text("복구") }
                        }
                    }
                    if (open) {
                        b.ops.take(100).forEach { o ->
                            Text(o.fromPath + " → " + o.toPath.ifEmpty { "(삭제됨)" }, style = MaterialTheme.typography.bodySmall)
                        }
                        if (b.ops.size > 100) Text("… 외 ${b.ops.size - 100}건", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
    confirmBatch?.let { b -> ConfirmDialog("'${b.title}' 작업을 되돌립니다. 삭제된 파일은 복구되지 않습니다.", { confirmBatch = null; vm.undo(b) }, { confirmBatch = null }) }
}

@Composable
fun SettingsScreen(vm: AppVM) {
    var text by remember { mutableStateOf("") }
    LazyColumn(contentPadding = PAD, verticalArrangement = GAP) {
        item { FolderCard(vm) }
        item { Text("제외 폴더 (폴더 이름 기준 · 하위 폴더 포함 검색 시 건너뜀)", style = MaterialTheme.typography.titleSmall) }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = text, onValueChange = { text = it }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("폴더 이름") })
                Button(onClick = { vm.addExcluded(text); text = "" }) { Text("추가") }
            }
        }
        items(vm.excluded.toList()) { n ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text(n); TextButton(onClick = { vm.removeExcluded(n) }) { Text("삭제") }
            }
        }
    }
}
