# 파일정리 (FileCleaner)

안드로이드 파일정리 앱. Kotlin + Jetpack Compose, GitHub Actions로 APK 빌드.

## 빌드
1. 이 폴더 전체를 GitHub 저장소에 올립니다 (폴더 구조 그대로).
2. 저장소의 Actions 탭에서 "Build APK"가 끝나기를 기다립니다.
3. 실행 결과 아래 Artifacts의 FileCleaner-APK를 받아 압축을 풀고 app-debug.apk를 설치합니다.

## 사람 인식 (새 기능)
앱 하단 **사람** 탭에서 사용합니다. 모두 기기 안에서만 처리되고 인터넷 권한이 없습니다.

1. **얼굴 분석 시작** — 홈에서 고른 폴더(하위 폴더 포함)의 사진에서 얼굴을 찾아 사람별로 묶습니다.
2. 사람을 눌러 **이름 붙이기 / 합치기 / 숨기기**, 잘못 들어온 사진은 **이 사람 아님**으로 뺍니다.
3. **사진으로 찾기** — 사진 한 장을 고르면 같은 사람이 나온 사진을 모아 줍니다.
4. **정리하기** — 원하는 저장 폴더를 고르고 `2024/03` 또는 `2024년/03월` 구조로 복사/이동합니다.
   - 사람별: `저장폴더/사람이름/2024/03/사진.jpg`
   - 전체 사진: `저장폴더/2024/03/사진.jpg`
   - 날짜 기준: EXIF 촬영일 → 파일명 날짜 → 수정일
   - 모든 작업은 **기록** 탭에서 되돌릴 수 있습니다.

### 얼굴 인식 모델 (필수)
얼굴을 구별하려면 임베딩 모델(`face_model.tflite`, 입력 정사각 RGB float32)이 필요합니다.
- 빌드 시: GitHub Actions가 MobileFaceNet 모델을 `app/src/main/assets/face_model.tflite`로 내려받습니다. 실패해도 빌드는 계속됩니다.
- 직접: 원하는 모델 파일을 위 경로에 넣어 올리거나, 앱 **사람** 탭에서 "모델 파일 선택"으로 불러옵니다.
- 입력 크기(112/160 등)와 출력 차원은 모델에서 자동으로 읽습니다. 모델을 바꾸면 얼굴 데이터는 새로 만듭니다.


## ArcFace ONNX model support (1.2)

- Supports importing `w600k_r50.onnx` through the People screen's model picker.
- Uses ONNX Runtime Android and opens the model by file path (does not copy the 174 MB model into a second in-memory byte array).
- Expected InsightFace recognition input: square RGB bitmap converted to BGR NCHW and normalized to [-1, 1]; output embedding is L2-normalized.
- The original TFLite asset path remains available as a fallback when no ONNX file has been imported.
- On model-signature change, old face embeddings are not mixed with the new model. A pre-change database and thumbnail snapshot is kept in app-private storage before the active face database is rebuilt. Existing face groups must be re-analyzed because embeddings from different models are not comparable.
- The app project does not bundle the 174 MB ONNX model. Extract `w600k_r50.onnx` from its ZIP on the phone and import the `.onnx` file in the People screen.
