package app.filecleaner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import java.security.MessageDigest

object Analyzer {
    val IMG = setOf("jpg", "jpeg", "png", "webp")
    private val PARTIAL = setOf("crdownload", "part", "download", "partial", "opdownload")
    private val AUDIO = setOf("mp3", "m4a", "amr", "3gp", "aac", "wav", "ogg", "flac", "opus")
    private val DATE_RE = Regex("^\\d{4}-\\d{2}-\\d{2}_")
    private const val DAY = 86_400_000L

    private fun junkSet(st: Settings): Set<String> =
        st.junk.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }.toSet()

    private fun isPartial(f: FileItem) = f.ext in PARTIAL
    private fun isJunk(f: FileItem, set: Set<String>) = f.size > 0 && (f.ext in set || f.name.lowercase() in set)

    fun quick(sc: ScanResult, st: Settings): Pair<Int, Long> {
        val junk = junkSet(st)
        var n = sc.dirs.count { it.empty }
        var bytes = 0L
        for (f in sc.files) if (f.size == 0L || isPartial(f) || isJunk(f, junk)) { n++; bytes += f.size }
        return n to bytes
    }

    private fun sha256(ctx: Context, uri: Uri): String? {
        return try {
            val md = MessageDigest.getInstance("SHA-256")
            val s = ctx.contentResolver.openInputStream(uri) ?: return null
            s.use {
                val b = ByteArray(65536)
                while (true) {
                    val n = it.read(b)
                    if (n < 0) break
                    md.update(b, 0, n)
                }
            }
            md.digest().joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            null
        }
    }

    private fun ahash(ctx: Context, uri: Uri): Long? {
        return try {
            val cr = ctx.contentResolver
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / (s * 2) >= 64 && o.outHeight / (s * 2) >= 64) s *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = s }
            val bm = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return null
            val sm = Bitmap.createScaledBitmap(bm, 8, 8, true)
            val g = IntArray(64) {
                val p = sm.getPixel(it % 8, it / 8)
                (Color.red(p) * 299 + Color.green(p) * 587 + Color.blue(p) * 114) / 1000
            }
            val avg = g.average()
            var h = 0L
            for (i in 0 until 64) if (g[i] > avg) h = h or (1L shl i)
            if (sm !== bm) sm.recycle()
            bm.recycle()
            h
        } catch (e: Throwable) {
            null
        }
    }

    private fun isCall(name: String): Boolean {
        val n = name.lowercase()
        return n.contains("call") || n.contains("통화") || n.contains("녹음") || n.contains("recording")
    }

    fun analyze(ctx: Context, sc: ScanResult, st: Settings, stage: (String) -> Unit, active: () -> Boolean): Map<Rule, List<Cand>> {
        val out = LinkedHashMap<Rule, List<Cand>>()
        val now = System.currentTimeMillis()
        val files = sc.files
        val junk = junkSet(st)
        val oldMs = st.oldDays * DAY
        val shotMs = st.shotDays * DAY
        stage("기본 규칙 검사 중")

        out[Rule.ZERO] = files.filter { it.size == 0L }.map { Cand(it, Act.TRASH, "0바이트") }
        out[Rule.EMPTY] = sc.dirs.filter { it.empty }
            .map { Cand(FileItem(it.uri, it.name, 0, 0, it.rel, "", true), Act.RMDIR, "빈 폴더") }
        out[Rule.PARTIAL] = files.filter { isPartial(it) }.map { Cand(it, Act.TRASH, "받다 만 파일") }
        out[Rule.JUNK] = files.filter { isJunk(it, junk) && !isPartial(it) }.map { Cand(it, Act.TRASH, "정크·임시 파일") }
        out[Rule.APK] = files.filter { (it.ext == "apk" || it.ext == "xapk") && it.modified > 0 && now - it.modified > oldMs }
            .map { Cand(it, Act.TRASH, "수정일 ${fmtDate(it.modified)}") }
        out[Rule.SHOT] = files.filter {
            it.ext in IMG && it.modified > 0 && now - it.modified > shotMs &&
                (it.name.lowercase().contains("screenshot") || it.name.contains("스크린샷"))
        }.map { Cand(it, Act.TRASH, "수정일 ${fmtDate(it.modified)}") }
        out[Rule.OLD] = files.filter { it.size > 0 && it.modified > 0 && now - it.modified > oldMs }
            .sortedByDescending { it.size }.take(500).map { Cand(it, Act.TRASH, "수정일 ${fmtDate(it.modified)}") }
        out[Rule.LARGE] = files.filter { it.size >= st.largeMb * 1048576L }
            .sortedByDescending { it.size }.take(300).map { Cand(it, Act.TRASH, "큰 파일") }

        stage("중복 파일 찾는 중")
        val dups = ArrayList<Cand>()
        val groups = files.filter { it.size > 0 }.groupBy { it.size }.values.filter { it.size > 1 }
        var done = 0
        for (g in groups) {
            if (!active()) break
            val byHash = HashMap<String, MutableList<FileItem>>()
            for (f in g) {
                val h = sha256(ctx, Uri.parse(f.uri)) ?: continue
                byHash.getOrPut(h) { ArrayList() }.add(f)
            }
            for (same in byHash.values) {
                if (same.size < 2) continue
                val sorted = same.sortedBy { it.modified }
                val keep = if (st.keep == Keep.OLDEST) sorted.first() else sorted.last()
                same.filter { it !== keep }.forEach { dups.add(Cand(it, Act.TRASH, "같은 파일: ${keep.path}")) }
            }
            done++
            if (done % 20 == 0) stage("중복 파일 찾는 중 ($done/${groups.size})")
        }
        out[Rule.DUP] = dups

        stage("비슷한 사진 찾는 중")
        val imgs = files.filter { it.ext in IMG && it.size > 0 }.sortedByDescending { it.modified }.take(1500)
        val hs = ArrayList<Pair<FileItem, Long>>()
        for ((i, f) in imgs.withIndex()) {
            if (!active()) break
            ahash(ctx, Uri.parse(f.uri))?.let { hs.add(f to it) }
            if (i % 50 == 0) stage("비슷한 사진 찾는 중 ($i/${imgs.size})")
        }
        val used = BooleanArray(hs.size)
        val sims = ArrayList<Cand>()
        for (i in hs.indices) {
            if (used[i]) continue
            val grp = arrayListOf(hs[i].first)
            for (j in i + 1 until hs.size) {
                if (!used[j] && java.lang.Long.bitCount(hs[i].second xor hs[j].second) <= 4) {
                    used[j] = true
                    grp.add(hs[j].first)
                }
            }
            if (grp.size > 1) {
                used[i] = true
                val sorted = grp.sortedBy { it.modified }
                val keep = if (st.keep == Keep.OLDEST) sorted.first() else sorted.last()
                grp.filter { it !== keep }.forEach { sims.add(Cand(it, Act.TRASH, "비슷한 사진: ${keep.name}")) }
            }
        }
        out[Rule.SIMILAR] = sims

        val top = files.filter { it.rel.isEmpty() }
        out[Rule.BYTYPE] = top.map { Cand(it, Act.MOVE, "→ ${Cat.of(it.ext)}", dest = Cat.of(it.ext)) }
        out[Rule.BYDATE] = top.filter { it.modified > 0 }.map {
            val d = fmtDate(it.modified, "yyyy/MM")
            Cand(it, Act.MOVE, "→ $d", dest = d)
        }
        out[Rule.CALL] = top.filter { it.ext in AUDIO && isCall(it.name) }
            .map { Cand(it, Act.MOVE, "→ 통화녹음", dest = "통화녹음") }
        out[Rule.RENAME] = top.filter { it.modified > 0 && !DATE_RE.containsMatchIn(it.name) }.map {
            val nn = fmtDate(it.modified) + "_" + it.name
            Cand(it, Act.RENAME, "→ $nn", newName = nn)
        }
        return out
    }
}
