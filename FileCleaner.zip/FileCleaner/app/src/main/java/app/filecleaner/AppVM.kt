package app.filecleaner

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException
import java.util.UUID
import java.util.concurrent.atomic.AtomicInteger

class Plan(val cands: List<Cand>, val move: Boolean, val destLabel: String, val lines: List<String>)

class AppVM(private val app: Application) : AndroidViewModel(app) {
    val st = Settings(app)
    val faces = FaceStore(app)
    var tab by mutableIntStateOf(0)
    var current by mutableStateOf<Rule?>(null)
    var rootUri by mutableStateOf(st.rootUri)
    var destUri by mutableStateOf(st.destUri)
    var scanning by mutableStateOf(false)
    var stage by mutableStateOf("")
    var found by mutableIntStateOf(0)
    var scanned by mutableStateOf(false)
    var results by mutableStateOf<Map<Rule, List<Cand>>>(emptyMap())
    var running by mutableStateOf(false)
    var done by mutableIntStateOf(0)
    var total by mutableIntStateOf(0)
    var message by mutableStateOf<String?>(null)
    var logs by mutableStateOf(st.logs())

    // 사람 / 얼굴
    var people by mutableStateOf<List<PersonSummary>>(emptyList())
    var peopleVer by mutableIntStateOf(0)
    var analyzed by mutableIntStateOf(0)
    var faceTotal by mutableIntStateOf(0)
    var modelOk by mutableStateOf(FaceEngine.hasModel(app))
    var viewPerson by mutableStateOf<Int?>(null)
    var searchPhotos by mutableStateOf<List<PhotoRec>>(emptyList())
    var bg by mutableStateOf(false)
    var bgStage by mutableStateOf("")
    var bgDone by mutableIntStateOf(0)
    var bgTotal by mutableIntStateOf(0)
    var plan by mutableStateOf<Plan?>(null)

    private var job: Job? = null

    init {
        viewModelScope.launch(Dispatchers.IO) {
            Ops.purgeOld(app, st)
            logs = st.logs()
        }
        refreshPeople()
    }

    private fun busy() = scanning || running || bg

    fun setRoot(u: String) {
        st.rootUri = u
        rootUri = u
        scanned = false
        results = emptyMap()
    }

    fun setDest(u: String) {
        st.destUri = u
        destUri = u
    }

    fun reclaimable(): Long = results.filterKeys { it.checked && !it.organize }.values.flatten()
        .filter { it.act != Act.RMDIR }.distinctBy { it.item.uri }.sumOf { it.item.size }

    fun close() { current = null }

    fun cancel() { job?.cancel() }

    fun startScan() {
        if (busy()) return
        if (st.rootUri.isEmpty()) { message = "먼저 정리할 폴더를 선택하세요."; return }
        scanning = true
        found = 0
        stage = "폴더 읽는 중"
        job = viewModelScope.launch(Dispatchers.IO) {
            try {
                val excluded = st.excludedList().map { it.lowercase() }.toSet()
                val sc = FileScanner.scan(app, Uri.parse(st.rootUri), excluded, { found = it }, { isActive })
                val res = Analyzer.analyze(app, sc, st, { stage = it }, { isActive })
                if (isActive) { results = res; scanned = true }
            } catch (e: Exception) {
                message = "스캔 실패: ${e.message}"
            } finally {
                scanning = false
            }
        }
    }

    fun execute(cands: List<Cand>, unlimited: Boolean = false) {
        if (running || bg) return
        val root = Ops.root(app, st)
        if (root == null) { message = "폴더 접근 권한을 확인하세요."; return }
        val rootStr = st.rootUri
        val list = if (unlimited) cands else cands.take(st.maxBatch)
        running = true
        done = 0
        total = list.size
        job = viewModelScope.launch(Dispatchers.IO) {
            val batch = UUID.randomUUID().toString()
            val newLogs = ArrayList<LogEntry>()
            val finished = HashSet<String>()
            var fail = 0
            var skip = 0
            Ops.clearCache()
            try {
                for (c in list) {
                    if (!isActive) break
                    try {
                        val e = Ops.run(app, st, root, rootStr, c, batch)
                        if (e != null) { newLogs.add(e); finished.add(c.item.uri) } else skip++
                    } catch (ex: Exception) {
                        fail++
                    }
                    done++
                }
            } finally {
                Ops.clearCache()
                st.appendLogs(newLogs)
                val moved = list.filter { it.act == Act.MOVE && it.item.uri in finished }.map { it.item.uri }
                if (moved.isNotEmpty()) { faces.removePhotos(moved); faces.save() }
                results = results.mapValues { (_, v) -> v.filter { it.item.uri !in finished } }
                logs = st.logs()
                refreshPeople()
                running = false
                var msg = "완료: ${newLogs.size}개 처리"
                if (skip > 0) msg += ", 건너뜀 ${skip}개 (이미 있음)"
                if (fail > 0) msg += ", 실패 ${fail}개"
                if (!unlimited && cands.size > list.size) msg += "\n한 번에 처리하는 최대 개수(${st.maxBatch}개)만 처리했어요. 한 번 더 실행하세요."
                message = msg
            }
        }
    }

    fun undo(entries: List<LogEntry>) {
        if (running || bg) return
        running = true
        done = 0
        total = entries.size
        job = viewModelScope.launch(Dispatchers.IO) {
            var ok = 0
            val all = st.logs().toMutableList()
            try {
                for (e in entries) {
                    if (!isActive) break
                    if (Ops.undo(app, e)) {
                        ok++
                        val i = all.indexOfFirst { it.id == e.id }
                        if (i >= 0) all[i] = all[i].copy(state = "UNDONE")
                    }
                    done++
                }
            } finally {
                st.saveLogs(all)
                logs = all
                scanned = false
                results = emptyMap()
                running = false
                message = "되돌림: $ok/${entries.size}개\n목록이 바뀌었으니 다시 스캔하세요."
            }
        }
    }

    fun purge(entries: List<LogEntry>) {
        viewModelScope.launch(Dispatchers.IO) {
            val ids = entries.map { it.id }.toSet()
            entries.forEach { Ops.purge(app, it) }
            val all = st.logs().map { if (it.id in ids) it.copy(state = "PURGED") else it }
            st.saveLogs(all)
            logs = all
        }
    }

    // ------------------------------------------------------------------
    // 사람 / 얼굴
    // ------------------------------------------------------------------

    fun refreshPeople() {
        people = faces.summaries(st.minPhotos)
        analyzed = faces.photoCount()
        faceTotal = faces.faceCount()
        peopleVer++
    }

    fun openPerson(id: Int) { viewPerson = id }

    fun closePerson() {
        viewPerson = null
        refreshPeople()
    }

    private fun skipImg(f: FileItem): Boolean {
        val r = f.rel.lowercase()
        return f.size < 20_000 || f.name.startsWith(".") || r.contains(".thumbnails") || r.contains("thumbnail")
    }

    fun importModel(uri: Uri) {
        if (busy()) return
        viewModelScope.launch(Dispatchers.IO) {
            val f = FaceEngine.modelFile(app)
            val tmp = File(f.path + ".new")
            try {
                app.contentResolver.openInputStream(uri)?.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                    ?: throw IOException("read")
                FaceEngine.reset()
                if (f.exists()) f.delete()
                tmp.renameTo(f)
                if (FaceEngine.init(app)) {
                    modelOk = true
                    message = "모델을 불러왔어요. (입력 ${FaceEngine.inSize}px, ${FaceEngine.outDim}차원)"
                } else {
                    f.delete()
                    modelOk = FaceEngine.hasModel(app)
                    message = FaceEngine.error.ifEmpty { "모델을 열 수 없어요." }
                }
            } catch (e: Exception) {
                tmp.delete()
                message = "모델 파일을 읽지 못했어요."
            }
        }
    }

    fun scanFaces(recluster: Boolean = false) {
        if (busy()) return
        if (st.rootUri.isEmpty()) { message = "먼저 정리할 폴더를 선택하세요. (홈 탭)"; return }
        if (!FaceEngine.hasModel(app)) { message = "얼굴 인식 모델 파일이 필요해요."; return }
        bg = true
        bgStage = "폴더 읽는 중"
        bgDone = 0
        bgTotal = 0
        job = viewModelScope.launch(Dispatchers.IO) {
            try {
                if (!FaceEngine.init(app)) { message = FaceEngine.error.ifEmpty { "모델을 열 수 없어요." }; return@launch }
                faces.ensureSig(FaceEngine.sig)
                val excluded = st.excludedList().map { it.lowercase() }.toSet()
                val sc = FileScanner.scan(app, Uri.parse(st.rootUri), excluded, { bgDone = it }, { isActive })
                if (!isActive) return@launch
                val imgs = sc.files.filter { it.ext in FaceEngine.IMG && !skipImg(it) }
                faces.prune(imgs.map { it.uri }.toSet())
                val todo = imgs.filter { !faces.isDone(it) }
                bgStage = "얼굴 찾는 중"
                bgTotal = todo.size
                bgDone = 0
                val counter = AtomicInteger(0)
                // 얼굴 검출·비트맵·TFLite 추론은 메모리 피크가 커서 S23+에서도 단일 작업으로 순차 처리한다.
                parallelFor(todo.size, 1) { i ->
                    val f = todo[i]
                    val a = try { FaceEngine.analyze(app, Uri.parse(f.uri), f.name, f.modified) } catch (e: Throwable) { null }
                    if (a != null) faces.addPhoto(f, a)
                    val d = counter.incrementAndGet()
                    bgDone = d
                    if (d % 100 == 0) faces.save()
                }
                if (!isActive) return@launch
                bgStage = "사람 묶는 중"
                bgTotal = 0
                bgDone = 0
                if (recluster) faces.resetUnnamed()
                faces.cluster(st.faceSim, { bgStage = it }, { isActive })
                faces.save()
                refreshPeople()
                message = "완료: 새 사진 ${todo.size}장 분석 · 사람 ${people.size}명 찾음"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = "얼굴 분석 실패: ${e.message}"
            } finally {
                faces.save()
                refreshPeople()
                bg = false
            }
        }
    }

    fun searchByPhoto(uri: Uri) {
        if (busy()) return
        if (!FaceEngine.hasModel(app)) { message = "얼굴 인식 모델 파일이 필요해요."; return }
        if (faces.photoCount() == 0) { message = "먼저 '얼굴 분석 시작'을 해주세요."; return }
        bg = true
        bgStage = "얼굴 찾는 중"
        bgDone = 0
        bgTotal = 0
        job = viewModelScope.launch(Dispatchers.IO) {
            try {
                if (!FaceEngine.init(app)) { message = FaceEngine.error.ifEmpty { "모델을 열 수 없어요." }; return@launch }
                val a = FaceEngine.analyze(app, uri, "", 0L)
                val best = a?.faces?.maxByOrNull { it.q }
                if (best == null) { message = "사진에서 얼굴을 찾지 못했어요."; return@launch }
                val res = faces.search(best.emb, st.faceSim / 100f - 0.05f)
                if (res.isEmpty()) { message = "같은 사람으로 보이는 사진이 없어요."; return@launch }
                searchPhotos = res
                viewPerson = -1
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = "검색 실패: ${e.message}"
            } finally {
                bg = false
            }
        }
    }

    fun renamePerson(id: Int, name: String) {
        faces.rename(id, name)
        faces.save()
        refreshPeople()
    }

    fun mergePerson(from: Int, into: Int) {
        faces.merge(from, into)
        faces.save()
        viewPerson = into
        refreshPeople()
    }

    fun hidePerson(id: Int) {
        faces.hide(id)
        faces.save()
        closePerson()
    }

    fun rejectPhotos(id: Int, uris: Collection<String>) {
        faces.reject(id, uris)
        faces.save()
        refreshPeople()
    }

    fun resetFaces() {
        if (busy()) return
        viewModelScope.launch(Dispatchers.IO) {
            faces.clearAll()
            refreshPeople()
            message = "얼굴 데이터를 지웠어요."
        }
    }

    // ------------------------------------------------------------------
    // 원하는 폴더로 연/월 정리
    // ------------------------------------------------------------------

    private fun checkDest(): Boolean {
        if (st.rootUri.isEmpty()) { message = "먼저 정리할 폴더를 선택하세요. (홈 탭)"; return false }
        if (st.destUri.isEmpty()) { message = "저장할 폴더를 먼저 선택하세요."; return false }
        return true
    }

    private fun destRootParam(): String = if (st.destUri == st.rootUri) "" else st.destUri

    private fun makePlan(cands: List<Cand>, move: Boolean) {
        if (cands.isEmpty()) { message = "옮길 파일이 없어요. (이미 정리되어 있거나 대상이 없어요)"; return }
        val lines = cands.groupBy { it.dest.substringBefore('/') }.entries.sortedBy { it.key }
            .take(10).map { "${it.key}  ${it.value.size}개" }
        plan = Plan(cands, move, rootLabel(st.destUri), lines)
    }

    /** 선택한 폴더 안의 모든 사진(옵션: 영상)을 촬영일 기준 연/월 폴더로 */
    fun planByDate() {
        if (busy() || !checkDest()) return
        val style = st.destStyle
        val move = st.moveMode
        val exts = if (st.incVideo) Dates.PHOTO + Dates.VIDEO else Dates.PHOTO
        val dr = destRootParam()
        bg = true
        bgStage = "폴더 읽는 중"
        bgDone = 0
        bgTotal = 0
        job = viewModelScope.launch(Dispatchers.IO) {
            try {
                val excluded = st.excludedList().map { it.lowercase() }.toSet()
                val sc = FileScanner.scan(app, Uri.parse(st.rootUri), excluded, { bgDone = it }, { isActive })
                if (!isActive) return@launch
                val files = sc.files.filter { it.ext in exts && !it.name.startsWith(".") }
                bgStage = "촬영 날짜 읽는 중"
                bgTotal = files.size
                bgDone = 0
                val dates = LongArray(files.size)
                val counter = AtomicInteger(0)
                parallelFor(files.size, 3) { i ->
                    dates[i] = Dates.resolve(app, files[i])
                    bgDone = counter.incrementAndGet()
                }
                if (!isActive) return@launch
                val cands = ArrayList<Cand>()
                for (i in files.indices) {
                    val rel = Dates.rel(dates[i], style)
                    if (dr.isEmpty() && files[i].rel == rel) continue
                    cands.add(Cand(files[i], if (move) Act.MOVE else Act.COPY, "→ $rel", dest = rel, destRoot = dr))
                }
                makePlan(cands, move)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = "계획 만들기 실패: ${e.message}"
            } finally {
                bg = false
            }
        }
    }

    /**
     * 사람별 정리. ids의 각 사람 폴더 아래에 연/월 폴더를 만든다.
     * only가 null이 아니면 그 사진들만 대상으로 한다.
     * 한 사진에 여러 사람이 있으면 각 사람 폴더에 복사본이 생긴다.
     * (이동 모드에서는 마지막 한 곳만 이동, 나머지는 복사)
     */
    fun planPeople(ids: List<Int>, only: Set<String>?) {
        if (busy() || !checkDest()) return
        val style = st.destStyle
        val move = st.moveMode
        val dr = destRootParam()
        val byPhoto = LinkedHashMap<String, Pair<PhotoRec, MutableList<String>>>()
        for (id in ids) {
            val folder = faces.folderOf(id)
            for (p in faces.photosOf(id)) {
                if (only != null && p.uri !in only) continue
                val e = byPhoto.getOrPut(p.uri) { p to ArrayList<String>() }
                if (folder !in e.second) e.second.add(folder)
            }
        }
        val copies = ArrayList<Cand>()
        val moves = ArrayList<Cand>()
        for ((_, e) in byPhoto) {
            val p = e.first
            val rel = Dates.rel(p.date, style)
            e.second.forEachIndexed { k, folder ->
                val dest = "$folder/$rel"
                if (dr.isEmpty() && p.rel == dest) return@forEachIndexed
                val last = k == e.second.size - 1
                val act = if (move && last) Act.MOVE else Act.COPY
                val c = Cand(p.toItem(), act, "→ $dest", dest = dest, destRoot = dr)
                if (act == Act.MOVE) moves.add(c) else copies.add(c)
            }
        }
        // 같은 사진의 복사는 반드시 이동보다 먼저
        makePlan(copies + moves, move)
    }

    /** 검색 결과 등 사람 폴더 없이 연/월로만 정리 */
    fun planPhotos(list: List<PhotoRec>) {
        if (busy() || !checkDest()) return
        val style = st.destStyle
        val move = st.moveMode
        val dr = destRootParam()
        val cands = ArrayList<Cand>()
        for (p in list) {
            val rel = Dates.rel(p.date, style)
            if (dr.isEmpty() && p.rel == rel) continue
            cands.add(Cand(p.toItem(), if (move) Act.MOVE else Act.COPY, "→ $rel", dest = rel, destRoot = dr))
        }
        makePlan(cands, move)
    }
}
