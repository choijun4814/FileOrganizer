package app.filecleaner

import android.content.Context
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.math.sqrt

data class PhotoRec(
    val idx: Int, val uri: String, val name: String, val rel: String,
    val size: Long, val modified: Long, val taken: Long
) {
    val ext: String get() = name.substringAfterLast('.', "").lowercase()
    val date: Long get() = if (taken > 0) taken else modified
    fun toItem() = FileItem(uri, name, size, modified, rel, mimeOf(ext))
}

class FaceRec(
    val id: Int, val photo: Int, val q: Float,
    val l: Float, val t: Float, val r: Float, val b: Float,
    val emb: FloatArray, var person: Int
)

class Person(val id: Int, var name: String, var hidden: Boolean)

data class PersonSummary(val id: Int, val name: String, val photos: Int, val faces: Int, val thumb: Int) {
    val label: String get() = name.ifEmpty { "사람 $id" }
}

fun mimeOf(ext: String): String = when (ext) {
    "jpg", "jpeg" -> "image/jpeg"
    "png" -> "image/png"
    "webp" -> "image/webp"
    "gif" -> "image/gif"
    "heic" -> "image/heic"
    "heif" -> "image/heif"
    "bmp" -> "image/bmp"
    "mp4" -> "video/mp4"
    "mov" -> "video/quicktime"
    "3gp" -> "video/3gpp"
    "mkv" -> "video/x-matroska"
    "avi" -> "video/x-msvideo"
    "webm" -> "video/webm"
    else -> "application/octet-stream"
}

private fun dot(a: FloatArray, b: FloatArray): Float {
    var s = 0f
    for (i in a.indices) s += a[i] * b[i]
    return s
}

private class Grp(val id: Int, d: Int) {
    val sum = FloatArray(d)
    val cent = FloatArray(d)
    val protos = ArrayList<FloatArray>()
    var n = 0

    private fun renorm() {
        var s = 0f
        for (v in sum) s += v * v
        var nr = sqrt(s)
        if (nr < 1e-6f) nr = 1f
        for (i in sum.indices) cent[i] = sum[i] / nr
    }

    fun add(e: FloatArray) {
        for (i in sum.indices) sum[i] += e[i]
        n++
        renorm()
        if (protos.size < 8) protos.add(e)
    }

    fun absorb(o: Grp) {
        for (i in sum.indices) sum[i] += o.sum[i]
        n += o.n
        renorm()
        for (p in o.protos) if (protos.size < 8) protos.add(p)
    }
}

/** 센트로이드 유사도 + 대표 얼굴 상위 2개 유사도를 섞은 점수 */
private fun score(e: FloatArray, g: Grp, sim: Float): Float {
    val c = dot(e, g.cent)
    if (c < sim - 0.2f || g.protos.size < 2) return c
    var m1 = -2f
    var m2 = -2f
    for (p in g.protos) {
        val s = dot(e, p)
        if (s > m1) { m2 = m1; m1 = s } else if (s > m2) m2 = s
    }
    return 0.6f * c + 0.4f * ((m1 + m2) / 2f)
}

class FaceStore(private val ctx: Context) {
    private val file = File(ctx.filesDir, "faces.db")
    val thumbDir: File = File(ctx.filesDir, "faces").apply { mkdirs() }

    private val photos = LinkedHashMap<String, PhotoRec>()
    private val photoById = HashMap<Int, PhotoRec>()
    private val faces = ArrayList<FaceRec>()
    private val persons = LinkedHashMap<Int, Person>()
    private var nextPhoto = 1
    private var nextFace = 1
    private var nextPerson = 1
    private var sig = ""
    private var dim = 0

    init { load() }

    fun thumbFile(id: Int): File = File(thumbDir, "$id.jpg")

    // ---------- 저장/불러오기 ----------

    private fun load() {
        if (!file.exists()) return
        try {
            DataInputStream(BufferedInputStream(FileInputStream(file), 1 shl 16)).use { i ->
                if (i.readInt() != MAGIC || i.readInt() != 1) return
                sig = i.readUTF()
                dim = i.readInt()
                nextPhoto = i.readInt()
                nextFace = i.readInt()
                nextPerson = i.readInt()
                repeat(i.readInt()) {
                    val id = i.readInt()
                    persons[id] = Person(id, i.readUTF(), i.readBoolean())
                }
                repeat(i.readInt()) {
                    val r = PhotoRec(i.readInt(), i.readUTF(), i.readUTF(), i.readUTF(), i.readLong(), i.readLong(), i.readLong())
                    photos[r.uri] = r
                    photoById[r.idx] = r
                }
                repeat(i.readInt()) {
                    val id = i.readInt()
                    val photo = i.readInt()
                    val q = i.readFloat()
                    val l = i.readFloat()
                    val t = i.readFloat()
                    val r = i.readFloat()
                    val b = i.readFloat()
                    val person = i.readInt()
                    val emb = FloatArray(dim) { i.readFloat() }
                    faces.add(FaceRec(id, photo, q, l, t, r, b, emb, person))
                }
            }
        } catch (e: Exception) {
            photos.clear(); photoById.clear(); faces.clear(); persons.clear()
            sig = ""; dim = 0
        }
    }

    @Synchronized
    fun save() {
        try {
            val tmp = File(file.path + ".tmp")
            DataOutputStream(BufferedOutputStream(FileOutputStream(tmp), 1 shl 16)).use { o ->
                o.writeInt(MAGIC); o.writeInt(1)
                o.writeUTF(sig); o.writeInt(dim)
                o.writeInt(nextPhoto); o.writeInt(nextFace); o.writeInt(nextPerson)
                o.writeInt(persons.size)
                for (p in persons.values) { o.writeInt(p.id); o.writeUTF(p.name); o.writeBoolean(p.hidden) }
                o.writeInt(photos.size)
                for (p in photos.values) {
                    o.writeInt(p.idx); o.writeUTF(p.uri); o.writeUTF(p.name); o.writeUTF(p.rel)
                    o.writeLong(p.size); o.writeLong(p.modified); o.writeLong(p.taken)
                }
                o.writeInt(faces.size)
                for (f in faces) {
                    o.writeInt(f.id); o.writeInt(f.photo); o.writeFloat(f.q)
                    o.writeFloat(f.l); o.writeFloat(f.t); o.writeFloat(f.r); o.writeFloat(f.b)
                    o.writeInt(f.person)
                    for (v in f.emb) o.writeFloat(v)
                }
            }
            if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file) }
        } catch (e: Exception) {
        }
    }

    // ---------- 데이터 관리 ----------

    @Synchronized
    fun clearAll() {
        thumbDir.listFiles()?.forEach { it.delete() }
        photos.clear(); photoById.clear(); faces.clear(); persons.clear()
        dim = 0
        save()
    }

    /** 모델이 바뀌면 이전 임베딩은 쓸 수 없으므로 비운다 */
    @Synchronized
    fun ensureSig(s: String) {
        if (sig != s) {
            if (sig.isNotEmpty() || faces.isNotEmpty()) clearAll()
            sig = s
        }
    }

    @Synchronized fun photoCount(): Int = photos.size
    @Synchronized fun faceCount(): Int = faces.size

    @Synchronized
    fun isDone(f: FileItem): Boolean {
        val p = photos[f.uri] ?: return false
        return p.size == f.size && p.modified == f.modified
    }

    @Synchronized
    fun removePhotos(uris: Collection<String>) {
        val idxs = HashSet<Int>()
        for (u in uris) photos.remove(u)?.let { idxs.add(it.idx); photoById.remove(it.idx) }
        if (idxs.isEmpty()) return
        val it = faces.iterator()
        while (it.hasNext()) {
            val f = it.next()
            if (f.photo in idxs) { thumbFile(f.id).delete(); it.remove() }
        }
    }

    @Synchronized
    fun prune(valid: Set<String>) {
        val gone = photos.keys.filter { it !in valid }
        if (gone.isNotEmpty()) removePhotos(gone)
    }

    @Synchronized
    fun addPhoto(f: FileItem, a: Analysis) {
        if (photos.containsKey(f.uri)) removePhotos(listOf(f.uri))
        val rec = PhotoRec(nextPhoto++, f.uri, f.name, f.rel, f.size, f.modified, a.taken)
        photos[rec.uri] = rec
        photoById[rec.idx] = rec
        for (d in a.faces) {
            val id = nextFace++
            try { thumbFile(id).writeBytes(d.thumb) } catch (e: Exception) {}
            dim = d.emb.size
            faces.add(FaceRec(id, rec.idx, d.q, d.l, d.t, d.r, d.b, d.emb, 0))
        }
    }

    // ---------- 묶기 ----------

    /** 이름 붙이거나 숨긴 사람은 그대로 두고, 나머지는 처음부터 다시 묶도록 초기화 */
    @Synchronized
    fun resetUnnamed() {
        for (f in faces) {
            if (f.person > 0) {
                val p = persons[f.person]
                if (p == null || (p.name.isEmpty() && !p.hidden)) f.person = 0
            }
        }
        persons.entries.removeAll { it.value.name.isEmpty() && !it.value.hidden }
    }

    @Synchronized
    fun cluster(simPct: Int, stage: (String) -> Unit, active: () -> Boolean) {
        if (faces.isEmpty() || dim == 0) return
        val sim = simPct / 100f
        val order = faces.sortedByDescending { it.q }

        fun build(): LinkedHashMap<Int, Grp> {
            val g = LinkedHashMap<Int, Grp>()
            for (f in order) if (f.person > 0) g.getOrPut(f.person) { Grp(f.person, dim) }.add(f.emb)
            return g
        }

        // 1) 새 얼굴을 기존 사람에 붙이거나 새 사람 만들기 (큰 얼굴부터)
        val grps = build()
        val fresh = order.filter { it.person == 0 }
        var cnt = 0
        for (f in fresh) {
            if (!active()) break
            var best: Grp? = null
            var bs = -2f
            for (g in grps.values) {
                val s = score(f.emb, g, sim)
                if (s > bs) { bs = s; best = g }
            }
            if (best != null && bs >= sim) {
                f.person = best.id
                best.add(f.emb)
            } else {
                val id = nextPerson++
                persons[id] = Person(id, "", false)
                f.person = id
                grps[id] = Grp(id, dim).also { it.add(f.emb) }
            }
            cnt++
            if (cnt % 300 == 0) stage("얼굴 묶는 중 ($cnt/${fresh.size})")
        }

        // 2) 확정된 중심으로 한 번 더 재배정 (처리 순서 때문에 생긴 오류 보정)
        if (active() && fresh.isNotEmpty()) {
            val g2 = build()
            for (f in fresh) {
                if (f.person <= 0) continue
                var best: Grp? = null
                var bs = -2f
                for (g in g2.values) {
                    val s = score(f.emb, g, sim)
                    if (s > bs) { bs = s; best = g }
                }
                if (best != null && best.id != f.person && bs >= sim + 0.02f) f.person = best.id
            }
        }

        // 3) 같은 사람으로 보이는 그룹 합치기
        if (active()) {
            stage("비슷한 사람 합치는 중")
            val g3 = build()
            val mt = minOf(0.92f, sim + 0.12f)
            val list = g3.values.toList()
            class Pr(val a: Int, val b: Int, val s: Float)
            val pairs = ArrayList<Pr>()
            for (x in list.indices) {
                for (y in x + 1 until list.size) {
                    val s = dot(list[x].cent, list[y].cent)
                    if (s >= mt) pairs.add(Pr(list[x].id, list[y].id, s))
                }
            }
            pairs.sortByDescending { it.s }
            val parent = HashMap<Int, Int>()
            fun root(x: Int): Int {
                var r = x
                var p = parent[r]
                while (p != null && p != r) { r = p; p = parent[r] }
                return r
            }
            for (pr in pairs) {
                val ra = root(pr.a)
                val rb = root(pr.b)
                if (ra == rb) continue
                val ga = g3[ra] ?: continue
                val gb = g3[rb] ?: continue
                val pa = persons[ra] ?: continue
                val pb = persons[rb] ?: continue
                if (pa.name.isNotEmpty() && pb.name.isNotEmpty()) continue
                if (pa.hidden != pb.hidden) continue
                if (dot(ga.cent, gb.cent) < mt) continue
                val keepA = when {
                    pa.name.isNotEmpty() -> true
                    pb.name.isNotEmpty() -> false
                    else -> ga.n >= gb.n
                }
                val win = if (keepA) ga else gb
                val lose = if (keepA) gb else ga
                win.absorb(lose)
                parent[lose.id] = win.id
            }
            if (parent.isNotEmpty()) {
                for (f in faces) if (f.person > 0) {
                    val r = root(f.person)
                    if (r != f.person) f.person = r
                }
            }
        }

        val used = HashSet<Int>()
        for (f in faces) if (f.person > 0) used.add(f.person)
        persons.keys.retainAll(used)
    }

    // ---------- 조회 ----------

    @Synchronized
    fun summaries(min: Int): List<PersonSummary> {
        val ph = HashMap<Int, HashSet<Int>>()
        val fc = HashMap<Int, Int>()
        val th = HashMap<Int, FaceRec>()
        for (f in faces) {
            if (f.person <= 0) continue
            ph.getOrPut(f.person) { HashSet() }.add(f.photo)
            fc[f.person] = (fc[f.person] ?: 0) + 1
            val cur = th[f.person]
            if (cur == null || f.q > cur.q) th[f.person] = f
        }
        val out = ArrayList<PersonSummary>()
        for (p in persons.values) {
            if (p.hidden) continue
            val n = ph[p.id]?.size ?: 0
            if (n == 0) continue
            if (n < min && p.name.isEmpty()) continue
            val t = th[p.id] ?: continue
            out.add(PersonSummary(p.id, p.name, n, fc[p.id] ?: 0, t.id))
        }
        return out.sortedByDescending { it.photos }
    }

    @Synchronized
    fun photosOf(id: Int): List<PhotoRec> {
        val s = HashSet<Int>()
        for (f in faces) if (f.person == id) s.add(f.photo)
        return s.mapNotNull { photoById[it] }.sortedByDescending { it.date }
    }

    @Synchronized
    fun nameOf(id: Int): String {
        val n = persons[id]?.name ?: ""
        return n.ifEmpty { "사람 $id" }
    }

    @Synchronized
    fun rawName(id: Int): String = persons[id]?.name ?: ""

    @Synchronized
    fun folderOf(id: Int): String = Dates.safeName(nameOf(id))

    @Synchronized
    fun search(e: FloatArray, thr: Float): List<PhotoRec> {
        val best = HashMap<Int, Float>()
        for (f in faces) {
            if (f.emb.size != e.size) continue
            val s = dot(f.emb, e)
            if (s >= thr && s > (best[f.photo] ?: -1f)) best[f.photo] = s
        }
        return best.keys.mapNotNull { photoById[it] }.sortedByDescending { best[it.idx] ?: 0f }
    }

    // ---------- 사람 편집 ----------

    @Synchronized
    fun rename(id: Int, name: String) { persons[id]?.name = name }

    @Synchronized
    fun hide(id: Int) { persons[id]?.hidden = true }

    @Synchronized
    fun merge(from: Int, into: Int) {
        if (from == into) return
        val a = persons[from]
        val b = persons[into]
        if (b != null && a != null && b.name.isEmpty()) b.name = a.name
        for (f in faces) if (f.person == from) f.person = into
        persons.remove(from)
    }

    /** 선택한 사진에서 '이 사람 아님' 처리: 이후로도 다시 붙지 않는다 */
    @Synchronized
    fun reject(id: Int, uris: Collection<String>) {
        val idxs = uris.mapNotNull { photos[it]?.idx }.toSet()
        for (f in faces) if (f.person == id && f.photo in idxs) f.person = -1
    }

    companion object {
        private const val MAGIC = 0x46434442
    }
}
