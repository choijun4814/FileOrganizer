package app.filecleaner

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document

object FileScanner {
    private class Child(val id: String, val name: String, val mime: String, val size: Long, val mod: Long)

    fun scan(ctx: Context, root: Uri, excluded: Set<String>, onProgress: (Int) -> Unit, active: () -> Boolean): ScanResult {
        val files = ArrayList<FileItem>()
        val dirs = ArrayList<DirInfo>()
        val cr = ctx.contentResolver
        val cols = arrayOf(
            Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME, Document.COLUMN_MIME_TYPE,
            Document.COLUMN_SIZE, Document.COLUMN_LAST_MODIFIED
        )

        fun walk(docId: String, rel: String): Int {
            val kids = ArrayList<Child>()
            val uri = DocumentsContract.buildChildDocumentsUriUsingTree(root, docId)
            try {
                cr.query(uri, cols, null, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        kids.add(
                            Child(
                                c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "",
                                if (c.isNull(3)) 0L else c.getLong(3), if (c.isNull(4)) 0L else c.getLong(4)
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                return -1
            }
            for (k in kids) {
                if (!active()) break
                if (k.mime == Document.MIME_TYPE_DIR) {
                    val full = if (rel.isEmpty()) k.name else "$rel/${k.name}"
                    if (excluded.contains(k.name.lowercase()) || excluded.contains(full.lowercase())) continue
                    val n = walk(k.id, full)
                    val u = DocumentsContract.buildDocumentUriUsingTree(root, k.id).toString()
                    dirs.add(DirInfo(u, k.name, rel, n == 0))
                } else {
                    val u = DocumentsContract.buildDocumentUriUsingTree(root, k.id).toString()
                    files.add(FileItem(u, k.name, k.size, k.mod, rel, k.mime))
                    if (files.size % 200 == 0) onProgress(files.size)
                }
            }
            return kids.size
        }

        walk(DocumentsContract.getTreeDocumentId(root), "")
        onProgress(files.size)
        return ScanResult(files, dirs)
    }
}
