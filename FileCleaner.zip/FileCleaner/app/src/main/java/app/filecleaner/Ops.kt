package app.filecleaner

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.util.UUID

object Fs {
    fun dir(root: DocumentFile, rel: String, create: Boolean): DocumentFile? {
        var cur: DocumentFile = root
        for (part in rel.split("/").filter { it.isNotEmpty() }) {
            val next = cur.findFile(part)
            cur = if (next != null && next.isDirectory) next
            else if (create) (cur.createDirectory(part) ?: return null)
            else return null
        }
        return cur
    }

    private fun uniqueName(dir: DocumentFile, name: String): String {
        if (dir.findFile(name) == null) return name
        val base = name.substringBeforeLast('.', name)
        val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
        var i = 1
        while (dir.findFile("$base ($i)$ext") != null) i++
        return "$base ($i)$ext"
    }

    fun put(ctx: Context, dir: DocumentFile, name: String, mime: String, policy: Policy, size: Long, open: () -> InputStream?): Uri? {
        var target = name
        val ex = dir.findFile(name)
        if (ex != null) {
            when (policy) {
                Policy.SKIP -> return null
                Policy.OVERWRITE -> ex.delete()
                Policy.RENAME -> target = uniqueName(dir, name)
            }
        }
        val out = dir.createFile(mime.ifEmpty { "application/octet-stream" }, target) ?: throw IOException("create")
        var ok = false
        try {
            open()?.use { i ->
                ctx.contentResolver.openOutputStream(out.uri, "w")?.use { o -> i.copyTo(o) } ?: throw IOException("out")
            } ?: throw IOException("in")
            ok = true
        } finally {
            if (!ok) out.delete()
        }
        if (size > 0 && out.length() != size) {
            out.delete()
            throw IOException("size")
        }
        return out.uri
    }

    fun deleteUri(ctx: Context, uri: Uri): Boolean =
        try { DocumentsContract.deleteDocument(ctx.contentResolver, uri) } catch (e: Exception) { false }

    fun isEmptyDir(ctx: Context, tree: Uri, doc: Uri): Boolean {
        val id = DocumentsContract.getDocumentId(doc)
        val u = DocumentsContract.buildChildDocumentsUriUsingTree(tree, id)
        return ctx.contentResolver.query(u, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID), null, null, null)
            ?.use { it.count == 0 } ?: false
    }
}

object Ops {
    private val dirCache = HashMap<String, DocumentFile>()

    @Synchronized
    fun clearCache() { dirCache.clear() }

    @Synchronized
    private fun cachedDir(base: DocumentFile, key: String, rel: String): DocumentFile? {
        val k = "$key|$rel"
        dirCache[k]?.let { return it }
        val d = Fs.dir(base, rel, true) ?: return null
        dirCache[k] = d
        return d
    }

    private fun sameDoc(a: Uri, b: Uri): Boolean = try {
        DocumentsContract.getDocumentId(a) == DocumentsContract.getDocumentId(b)
    } catch (e: Exception) {
        a == b
    }

    fun root(ctx: Context, st: Settings): DocumentFile? =
        st.rootUri.takeIf { it.isNotEmpty() }?.let { DocumentFile.fromTreeUri(ctx, Uri.parse(it)) }

    fun trashFile(ctx: Context, id: String): File = File(File(ctx.filesDir, "trash").apply { mkdirs() }, id)

    fun run(ctx: Context, st: Settings, root: DocumentFile, rootStr: String, c: Cand, batch: String): LogEntry? {
        val f = c.item
        val src = Uri.parse(f.uri)
        val id = UUID.randomUUID().toString()
        fun e(type: String, dst: String = "", newName: String = "", uri: String = "", state: String = "ACTIVE") =
            LogEntry(id, batch, System.currentTimeMillis(), type, f.name, newName, f.rel, dst, uri, rootStr, f.mime, f.size, state)

        return when (c.act) {
            Act.TRASH -> if (!st.useTrash) {
                if (!Fs.deleteUri(ctx, src)) throw IOException("delete")
                e("DELETE", state = "NOUNDO")
            } else {
                val tf = trashFile(ctx, id)
                ctx.contentResolver.openInputStream(src)?.use { i -> tf.outputStream().use { o -> i.copyTo(o) } }
                    ?: throw IOException("read")
                if (f.size > 0 && tf.length() != f.size) { tf.delete(); throw IOException("size") }
                if (!Fs.deleteUri(ctx, src)) { tf.delete(); throw IOException("delete") }
                e("TRASH")
            }
            Act.MOVE, Act.COPY -> {
                val base = if (c.destRoot.isEmpty()) root
                else DocumentFile.fromTreeUri(ctx, Uri.parse(c.destRoot)) ?: throw IOException("dest")
                val dir = cachedDir(base, c.destRoot, c.dest) ?: throw IOException("dest")
                if (f.size > 0) {
                    val ex = dir.findFile(f.name)
                    if (ex != null && ex.length() == f.size && (c.act == Act.COPY || sameDoc(ex.uri, src))) return null
                }
                val nu = Fs.put(ctx, dir, f.name, f.mime, st.policy, f.size) { ctx.contentResolver.openInputStream(src) }
                    ?: return null
                if (c.act == Act.MOVE && !Fs.deleteUri(ctx, src)) throw IOException("delete")
                e(if (c.act == Act.MOVE) "MOVE" else "COPY", dst = c.dest, uri = nu.toString())
            }
            Act.RENAME -> {
                val nu = DocumentsContract.renameDocument(ctx.contentResolver, src, c.newName)
                    ?: throw IOException("rename")
                e("RENAME", newName = c.newName, uri = nu.toString())
            }
            Act.RMDIR -> {
                if (!Fs.isEmptyDir(ctx, Uri.parse(rootStr), src)) return null
                if (!Fs.deleteUri(ctx, src)) throw IOException("rmdir")
                e("RMDIR", state = "NOUNDO")
            }
        }
    }

    fun undo(ctx: Context, e: LogEntry): Boolean {
        return try {
            val rootDoc = DocumentFile.fromTreeUri(ctx, Uri.parse(e.root)) ?: return false
            when (e.type) {
                "TRASH" -> {
                    val tf = trashFile(ctx, e.id)
                    if (!tf.exists()) return false
                    val dir = Fs.dir(rootDoc, e.srcRel, true) ?: return false
                    Fs.put(ctx, dir, e.name, e.mime, Policy.RENAME, e.size) { tf.inputStream() } ?: return false
                    tf.delete()
                    true
                }
                "MOVE" -> {
                    val dir = Fs.dir(rootDoc, e.srcRel, true) ?: return false
                    val cur = Uri.parse(e.uri)
                    Fs.put(ctx, dir, e.name, e.mime, Policy.RENAME, e.size) { ctx.contentResolver.openInputStream(cur) }
                        ?: return false
                    Fs.deleteUri(ctx, cur)
                    true
                }
                "COPY" -> Fs.deleteUri(ctx, Uri.parse(e.uri))
                "RENAME" -> DocumentsContract.renameDocument(ctx.contentResolver, Uri.parse(e.uri), e.name) != null
                else -> false
            }
        } catch (ex: Exception) {
            false
        }
    }

    fun purge(ctx: Context, e: LogEntry) { trashFile(ctx, e.id).delete() }

    fun purgeOld(ctx: Context, st: Settings) {
        val limit = System.currentTimeMillis() - st.trashDays * 86_400_000L
        var changed = false
        val out = st.logs().map { e ->
            if (e.type == "TRASH" && e.state == "ACTIVE" && e.time < limit) {
                purge(ctx, e); changed = true; e.copy(state = "PURGED")
            } else e
        }
        if (changed) st.saveLogs(out)
    }
}
