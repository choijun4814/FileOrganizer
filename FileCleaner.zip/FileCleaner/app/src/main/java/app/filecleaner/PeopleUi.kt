@file:OptIn(ExperimentalMaterial3Api::class)

package app.filecleaner

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

@Composable
fun OrganizeDialog(
    vm: AppVM,
    title: String,
    showVideo: Boolean,
    pickDest: () -> Unit,
    onGo: () -> Unit,
    onDismiss: () -> Unit
) {
    val st = vm.st
    var move by remember { mutableStateOf(st.moveMode) }
    var style by remember { mutableIntStateOf(st.destStyle) }
    var video by remember { mutableStateOf(st.incVideo) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("저장할 폴더", style = MaterialTheme.typography.labelMedium)
                OutlinedButton(onClick = pickDest, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Outlined.Folder, null)
                    Spacer(Modifier.size(8.dp))
                    Text(
                        if (vm.destUri.isEmpty()) "폴더 선택" else rootLabel(vm.destUri),
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                Text("방식", style = MaterialTheme.typography.labelMedium)
                ChipRow(listOf("복사 (원본 유지)", "이동"), if (move) 1 else 0) { move = it == 1; st.moveMode = move }
                Text("폴더 이름", style = MaterialTheme.typography.labelMedium)
                ChipRow(listOf("2024/03", "2024년/03월"), style) { style = it; st.destStyle = it }
                if (showVideo) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("영상도 함께", modifier = Modifier.weight(1f))
                        Switch(checked = video, onCheckedChange = { video = it; st.incVideo = it })
                    }
                }
                Text(
                    "날짜는 사진에 기록된 촬영일 → 파일 이름의 날짜 → 수정일 순서로 정해요.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = { TextButton(onClick = onGo, enabled = vm.destUri.isNotEmpty()) { Text("계획 보기") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("취소") } }
    )
}

@Composable
fun PeopleScreen(vm: AppVM, pickDest: () -> Unit) {
    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importModel(uri)
    }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.searchByPhoto(uri)
    }
    var org by remember { mutableIntStateOf(0) }

    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Text("사람", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 16.dp))
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!vm.modelOk) {
                        Text("얼굴 인식 모델이 필요해요", fontWeight = FontWeight.Medium)
                        Text(
                            "face_model.tflite 파일을 한 번만 선택하면 돼요. 모델은 1×정사각 RGB 입력의 FLOAT32 TFLite여야 해요. 빌드에 포함되면 자동으로 준비돼요.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Button(onClick = { modelPicker.launch(arrayOf("*/*")) }) { Text("모델 파일 선택") }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("얼굴 인식 준비됨", fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                            TextButton(onClick = { modelPicker.launch(arrayOf("*/*")) }) { Text("모델 바꾸기") }
                        }
                        Text(
                            "분석한 사진 ${vm.analyzed}장 · 얼굴 ${vm.faceTotal}개 · 사람 ${vm.people.size}명",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Button(onClick = { vm.scanFaces() }, modifier = Modifier.fillMaxWidth().height(48.dp)) { Text("얼굴 분석 시작") }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { photoPicker.launch("image/*") }, modifier = Modifier.weight(1f)) { Text("사진으로 찾기") }
                            OutlinedButton(onClick = { vm.scanFaces(true) }, modifier = Modifier.weight(1f)) { Text("다시 묶기") }
                        }
                    }
                }
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("원하는 폴더에 연/월로 정리", fontWeight = FontWeight.Medium)
                    Text(
                        "정리 대상은 홈 탭에서 고른 폴더 안의 사진이에요. 하위 폴더까지 모두 찾아요.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(onClick = { org = 1 }, modifier = Modifier.fillMaxWidth()) { Text("전체 사진 연/월 정리") }
                    OutlinedButton(
                        onClick = { org = 2 },
                        enabled = vm.people.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("사람별 폴더로 정리 (사람/연/월)") }
                }
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Text("사람 목록", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 4.dp))
        }
        if (vm.people.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    if (vm.analyzed == 0) "얼굴 분석을 시작하면 사람별로 모아서 보여줘요."
                    else "표시할 사람이 없어요. 설정에서 '최소 사진 수'를 낮춰보세요.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        items(vm.people, key = { it.id }) { p ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth().clickable { vm.openPerson(p.id) }
            ) {
                AsyncImage(
                    model = vm.faces.thumbFile(p.thumb),
                    contentDescription = null,
                    modifier = Modifier.size(84.dp).clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
                Spacer(Modifier.height(4.dp))
                Text(p.label, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                Text("${p.photos}장", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) { Spacer(Modifier.height(8.dp)) }
    }

    if (org != 0) {
        OrganizeDialog(
            vm = vm,
            title = if (org == 1) "전체 사진 연/월 정리" else "사람별 폴더로 정리",
            showVideo = org == 1,
            pickDest = pickDest,
            onGo = {
                val mode = org
                org = 0
                if (mode == 1) vm.planByDate() else vm.planPeople(vm.people.map { it.id }, null)
            },
            onDismiss = { org = 0 }
        )
    }
}

@Composable
fun PersonScreen(vm: AppVM, pickDest: () -> Unit) {
    val pid = vm.viewPerson ?: return
    val search = pid < 0
    val photos = remember(pid, vm.peopleVer, vm.searchPhotos) {
        if (search) vm.searchPhotos else vm.faces.photosOf(pid)
    }
    val sel = remember(pid, photos) {
        mutableStateMapOf<String, Boolean>().also { m -> photos.forEach { m[it.uri] = true } }
    }
    val chosen = photos.filter { sel[it.uri] == true }
    var dlg by remember { mutableIntStateOf(0) }
    var nameText by remember { mutableStateOf("") }
    BackHandler { vm.closePerson() }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.closePerson() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "뒤로") }
            Text(
                if (search) "검색 결과" else vm.faces.nameOf(pid),
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.weight(1f),
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            if (!search) {
                TextButton(onClick = { nameText = vm.faces.rawName(pid); dlg = 1 }) { Text("이름") }
                TextButton(onClick = { dlg = 2 }) { Text("합치기") }
                TextButton(onClick = { vm.hidePerson(pid) }) { Text("숨기기") }
            }
        }
        Text(
            "${photos.size}장 · 선택 ${chosen.size}장" + if (search) " · 비슷한 순서" else "",
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.weight(1f).fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            items(photos, key = { it.uri }) { p ->
                val on = sel[p.uri] == true
                Box(Modifier.fillMaxWidth().aspectRatio(1f).clickable { sel[p.uri] = !on }) {
                    AsyncImage(
                        model = p.uri,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize().alpha(if (on) 1f else 0.45f),
                        contentScale = ContentScale.Crop
                    )
                    Checkbox(checked = on, onCheckedChange = { sel[p.uri] = it }, modifier = Modifier.align(Alignment.TopStart))
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (!search) {
                OutlinedButton(onClick = { dlg = 4 }, enabled = chosen.isNotEmpty(), modifier = Modifier.weight(1f).height(48.dp)) {
                    Text("이 사람 아님")
                }
            }
            Button(onClick = { dlg = 3 }, enabled = chosen.isNotEmpty(), modifier = Modifier.weight(1f).height(48.dp)) {
                Text("정리하기")
            }
        }
    }

    if (dlg == 1) {
        AlertDialog(
            onDismissRequest = { dlg = 0 },
            title = { Text("이름 붙이기") },
            text = { OutlinedTextField(value = nameText, onValueChange = { nameText = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { vm.renamePerson(pid, nameText.trim()); dlg = 0 }) { Text("저장") } },
            dismissButton = { TextButton(onClick = { dlg = 0 }) { Text("취소") } }
        )
    }
    if (dlg == 2) {
        val others = vm.people.filter { it.id != pid }
        AlertDialog(
            onDismissRequest = { dlg = 0 },
            title = { Text("같은 사람이에요") },
            text = {
                if (others.isEmpty()) Text("합칠 다른 사람이 없어요.")
                else LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    items(others, key = { it.id }) { o ->
                        Row(
                            Modifier.fillMaxWidth().clickable { dlg = 0; vm.mergePerson(pid, o.id) }.padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AsyncImage(
                                model = vm.faces.thumbFile(o.thumb), contentDescription = null,
                                modifier = Modifier.size(44.dp).clip(CircleShape), contentScale = ContentScale.Crop
                            )
                            Spacer(Modifier.size(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(o.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${o.photos}장", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { dlg = 0 }) { Text("취소") } }
        )
    }
    if (dlg == 3) {
        OrganizeDialog(
            vm = vm,
            title = "선택한 ${chosen.size}장 정리",
            showVideo = false,
            pickDest = pickDest,
            onGo = {
                dlg = 0
                val uris = chosen.map { it.uri }.toSet()
                if (search) vm.planPhotos(chosen) else vm.planPeople(listOf(pid), uris)
            },
            onDismiss = { dlg = 0 }
        )
    }
    if (dlg == 4) {
        AlertDialog(
            onDismissRequest = { dlg = 0 },
            title = { Text("이 사람이 아닌가요?") },
            text = { Text("선택한 ${chosen.size}장에서 이 사람 표시를 지워요. 사진 파일은 그대로예요.") },
            confirmButton = { TextButton(onClick = { dlg = 0; vm.rejectPhotos(pid, chosen.map { it.uri }) }) { Text("지우기") } },
            dismissButton = { TextButton(onClick = { dlg = 0 }) { Text("취소") } }
        )
    }
}
