package app.filecleaner

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

private class StrPref(val p: SharedPreferences, val k: String, val d: String) : ReadWriteProperty<Any?, String> {
    override fun getValue(thisRef: Any?, property: KProperty<*>): String = p.getString(k, d) ?: d
    override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) { p.edit().putString(k, value).apply() }
}

private class IntPref(val p: SharedPreferences, val k: String, val d: Int) : ReadWriteProperty<Any?, Int> {
    override fun getValue(thisRef: Any?, property: KProperty<*>): Int = p.getInt(k, d)
    override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) { p.edit().putInt(k, value).apply() }
}

private class BoolPref(val p: SharedPreferences, val k: String, val d: Boolean) : ReadWriteProperty<Any?, Boolean> {
    override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = p.getBoolean(k, d)
    override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) { p.edit().putBoolean(k, value).apply() }
}

class Settings(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("fc", Context.MODE_PRIVATE)

    var rootUri by StrPref(p, "root", "")
    var junk by StrPref(p, "junk", "tmp,temp,log,bak,old,thumbdata,thumbdata3,thumbs.db,.ds_store")
    var excluded by StrPref(p, "excl", "")
    var oldDays by IntPref(p, "old", 365)
    var shotDays by IntPref(p, "shot", 30)
    var largeMb by IntPref(p, "large", 100)
    var trashDays by IntPref(p, "trashDays", 30)
    var maxBatch by IntPref(p, "batch", 500)
    var policyName by StrPref(p, "policy", "RENAME")
    var keepName by StrPref(p, "keep", "OLDEST")
    var auto by BoolPref(p, "auto", false)
    var useTrash by BoolPref(p, "useTrash", true)
    var destUri by StrPref(p, "dest", "")
    var destStyle by IntPref(p, "dstyle", 0)
    var moveMode by BoolPref(p, "mv", false)
    var faceSim by IntPref(p, "fsim", 55)
    var minPhotos by IntPref(p, "minp", 2)
    var incVideo by BoolPref(p, "incv", true)

    val policy: Policy get() = runCatching { Policy.valueOf(policyName) }.getOrDefault(Policy.RENAME)
    val keep: Keep get() = runCatching { Keep.valueOf(keepName) }.getOrDefault(Keep.OLDEST)

    fun excludedList(): List<String> = excluded.split("\n").map { it.trim() }.filter { it.isNotEmpty() }

    @Synchronized
    fun logs(): List<LogEntry> {
        val a = JSONArray(p.getString("log", "[]") ?: "[]")
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            LogEntry(
                o.getString("id"), o.getString("batch"), o.getLong("time"), o.getString("type"),
                o.getString("name"), o.optString("newName"), o.optString("srcRel"), o.optString("dstRel"),
                o.optString("uri"), o.optString("root"), o.optString("mime"), o.optLong("size"), o.getString("state")
            )
        }
    }

    @Synchronized
    fun saveLogs(l: List<LogEntry>) {
        val a = JSONArray()
        l.takeLast(2000).forEach { e ->
            a.put(
                JSONObject().put("id", e.id).put("batch", e.batch).put("time", e.time).put("type", e.type)
                    .put("name", e.name).put("newName", e.newName).put("srcRel", e.srcRel).put("dstRel", e.dstRel)
                    .put("uri", e.uri).put("root", e.root).put("mime", e.mime).put("size", e.size).put("state", e.state)
            )
        }
        p.edit().putString("log", a.toString()).apply()
    }

    @Synchronized
    fun appendLogs(l: List<LogEntry>) { saveLogs(logs() + l) }
}
